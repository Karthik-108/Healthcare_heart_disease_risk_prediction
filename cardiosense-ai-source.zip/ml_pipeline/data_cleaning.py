"""
CardioSense AI - CDC BRFSS 2021 Data Cleaning & Stratified Sampling Pipeline
Produces a clean, reproducible stratified sample of exactly 40,000 valid records.
Never generates, duplicates, or fabricates records.
"""

import os
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit

# Official CDC BRFSS 2021 Source URL & Metadata
CDC_BRFSS_2021_URL = "https://www.cdc.gov/brfss/annual_data/2021/files/LLCP2021XPT.zip"
TARGET_SAMPLE_SIZE = 40000
RANDOM_STATE = 42

# Column Mapping Dictionary for CDC BRFSS 2021
FEATURE_MAP = {
    '_MICHD': 'target_heart_disease',       # Target (1 = Yes, 2 = No)
    '_AGEG5YR': 'age_category',             # 1-13 (Age 18 to 80+), 14 = Refused
    'SEXVAR': 'sex',                        # 1 = Male, 2 = Female
    '_BMI5': 'bmi',                         # Continuous with 2 implied decimals (e.g. 2842 = 28.42)
    'SMOKDAY2': 'smoking_status',           # 1 = Everyday, 2 = Some days, 3 = Not at all
    '_DRNKWK1': 'alcohol_drinks_week',      # Number of drinks per week
    '_TOTINDA': 'physical_activity',        # 1 = Had physical activity, 2 = No
    'DIABETE4': 'diabetes',                 # 1 = Yes, 2 = Gestational, 3 = No, 4 = Pre-diabetes
    '_RFHYPE5': 'high_blood_pressure',      # 1 = No, 2 = Yes
    '_RFCHOL2': 'high_cholesterol',         # 1 = No, 2 = Yes
    'GENHLTH': 'general_health',            # 1 = Excellent, 2 = Very good, 3 = Good, 4 = Fair, 5 = Poor
    'SLEPTIM1': 'sleep_hours',              # 1-24 hours
    'DIFFWALK': 'diff_walking',             # 1 = Yes, 2 = No
    'CVDSTRK3': 'stroke',                   # 1 = Yes, 2 = No
    '_PRACE1': 'race_ethnicity',            # Fairness attribute only
    '_EDUCAG': 'education_level'            # Fairness attribute only
}


def clean_cdc_brfss_dataset(raw_df: pd.DataFrame) -> pd.DataFrame:
    """
    Cleans raw BRFSS survey responses:
    - Filters out missing (NaN), 'Don't know' (7, 77, 777), and 'Refused' (9, 99, 999).
    - Converts target _MICHD to binary 1/0.
    - Recodes categorical codes to semantic, non-leaking survey categories.
    """
    print(f"Initial raw record count: {len(raw_df):,}")
    
    # 1. Target Variable Cleaning (_MICHD)
    # In BRFSS: 1 = Reported CHD or MI, 2 = Did not report either. 77/99/Blank = Refused/Missing
    df = raw_df[raw_df['_MICHD'].isin([1, 2])].copy()
    df['target'] = (df['_MICHD'] == 1).astype(int)
    print(f"After target cleaning (_MICHD in [1, 2]): {len(df):,} records")
    print(f"Positive target prevalence in clean cohort: {df['target'].mean():.4%}")

    # 2. Age Cleaning (_AGEG5YR: 1 to 13 are valid 5-year cohorts; 14 is Refused)
    df = df[df['_AGEG5YR'].isin(range(1, 14))].copy()
    age_labels = {
        1: 'Age 18-24', 2: 'Age 25-29', 3: 'Age 30-34', 4: 'Age 35-39',
        5: 'Age 40-44', 6: 'Age 45-49', 7: 'Age 50-54', 8: 'Age 55-59',
        9: 'Age 60-64', 10: 'Age 65-69', 11: 'Age 70-74', 12: 'Age 75-79',
        13: 'Age 80 or older'
    }
    df['age_category'] = df['_AGEG5YR'].map(age_labels)

    # 3. Sex Cleaning (SEXVAR: 1 = Male, 2 = Female)
    df = df[df['SEXVAR'].isin([1, 2])].copy()
    df['sex'] = df['SEXVAR'].map({1: 'Male', 2: 'Female'})

    # 4. BMI Cleaning (_BMI5: continuous with 2 implied decimals; e.g. 2842 -> 28.42)
    # Valid adult biological bounds: 12.0 to 75.0 kg/m²
    df['bmi'] = df['_BMI5'] / 100.0
    df = df[(df['bmi'] >= 12.0) & (df['bmi'] <= 75.0)].copy()

    # 5. Smoking Status (SMOKDAY2)
    # 1: Everyday, 2: Some days, 3: Not at all
    # Also check if SMOKE100 was 2 (Never smoked <100 cigs)
    def clean_smoking(row):
        if row.get('SMOKE100') == 2:
            return 'Never smoked'
        day = row.get('SMOKDAY2')
        if day == 1:
            return 'Current smoker - everyday'
        elif day == 2:
            return 'Current smoker - some days'
        elif day == 3:
            return 'Former smoker'
        return np.nan

    df['smoking_status'] = df.apply(clean_smoking, axis=1)
    df = df.dropna(subset=['smoking_status']).copy()

    # 6. Physical Activity (_TOTINDA: 1 = Yes, 2 = No)
    df = df[df['_TOTINDA'].isin([1, 2])].copy()
    df['physical_activity'] = df['_TOTINDA'].map({1: 'Yes', 2: 'No'})

    # 7. Sleep Hours (SLEPTIM1: 1 to 24 hours valid; 77/99 Refused)
    df = df[df['SLEPTIM1'].isin(range(1, 25))].copy()
    df['sleep_hours'] = df['SLEPTIM1'].astype(int)

    # 8. High Blood Pressure (_RFHYPE5: 1 = No, 2 = Yes)
    df = df[df['_RFHYPE5'].isin([1, 2])].copy()
    df['high_blood_pressure'] = df['_RFHYPE5'].map({1: 'No', 2: 'Yes'})

    # 9. High Cholesterol (_RFCHOL2: 1 = No, 2 = Yes)
    df = df[df['_RFCHOL2'].isin([1, 2])].copy()
    df['high_cholesterol'] = df['_RFCHOL2'].map({1: 'No', 2: 'Yes'})

    # 10. Diabetes (DIABETE4: 1 = Yes, 2 = Gestational, 3 = No, 4 = Pre-diabetes)
    df = df[df['DIABETE4'].isin([1, 2, 3, 4])].copy()
    df['diabetes'] = df['DIABETE4'].map({
        1: 'Yes',
        2: 'Gestational only',
        3: 'No',
        4: 'Borderline / Pre-diabetes'
    })

    # 11. Stroke History (CVDSTRK3: 1 = Yes, 2 = No)
    df = df[df['CVDSTRK3'].isin([1, 2])].copy()
    df['stroke'] = df['CVDSTRK3'].map({1: 'Yes', 2: 'No'})

    # 12. General Health (GENHLTH: 1 = Excellent, 2 = Very good, 3 = Good, 4 = Fair, 5 = Poor)
    df = df[df['GENHLTH'].isin([1, 2, 3, 4, 5])].copy()
    df['general_health'] = df['GENHLTH'].map({
        1: 'Excellent',
        2: 'Very good',
        3: 'Good',
        4: 'Fair',
        5: 'Poor'
    })

    # 13. Difficulty Walking (DIFFWALK: 1 = Yes, 2 = No)
    df = df[df['DIFFWALK'].isin([1, 2])].copy()
    df['diff_walking'] = df['DIFFWALK'].map({1: 'Yes', 2: 'No'})

    # 14. Heavy Alcohol Drinking (_DRNKWK1: calculated drinks per week)
    def clean_alcohol(row):
        drinks = row.get('_DRNKWK1', 0)
        sex = row.get('sex')
        if pd.isna(drinks) or drinks >= 99900:
            return 'No'
        # Heavy drinking threshold: >14 drinks/wk (men), >7 drinks/wk (women)
        threshold = 14 if sex == 'Male' else 7
        return 'Yes' if (drinks / 100.0) > threshold else 'No'

    df['alcohol_drinking'] = df.apply(clean_alcohol, axis=1)

    print(f"Total fully clean records available before stratified sampling: {len(df):,}")
    return df


def generate_stratified_sample(clean_df: pd.DataFrame, target_n: int = 40000) -> pd.DataFrame:
    """
    Extracts an exact, reproducible stratified sample of target_n records
    matching the natural population target prevalence of heart disease.
    """
    assert len(clean_df) >= target_n, f"Not enough valid records ({len(clean_df)} < {target_n})"

    sss = StratifiedShuffleSplit(n_splits=1, train_size=target_n, random_state=RANDOM_STATE)
    sample_indices, _ = next(sss.split(clean_df, clean_df['target']))
    
    sample_df = clean_df.iloc[sample_indices].copy().reset_index(drop=True)
    
    print("\n================ STRATIFIED SAMPLE SUMMARY ================")
    print(f"Total records in sample: {len(sample_df):,}")
    print(f"Positive target count (_MICHD=1): {sample_df['target'].sum():,} ({sample_df['target'].mean():.2%})")
    print(f"Negative target count (_MICHD=0): {(sample_df['target'] == 0).sum():,} ({(sample_df['target'] == 0).mean():.2%})")
    print("===========================================================\n")
    
    return sample_df


if __name__ == "__main__":
    print("CardioSense AI - CDC BRFSS 2021 Data Cleaning Module initialized.")
