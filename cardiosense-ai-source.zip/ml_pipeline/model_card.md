# CardioSense AI — Model Card (v1.4.2)
**Format:** Mitchell et al. (2019) Standardized Model Card Framework

---

## 1. Model Details
- **Model Name:** CardioSense AI Calibrated HistGradientBoosting Classifier
- **Model Version:** `v1.4.2-calibrated-hgb`
- **Model Architecture:** Gradient Boosted Decision Tree Ensemble (equivalent to LightGBM histogram binning) with post-hoc Isotonic Regression Probability Calibration (`CalibratedClassifierCV`).
- **Release Date:** November 2026
- **License:** Apache 2.0 / Educational Public Health License
- **Frameworks:** Python 3.11, scikit-learn 1.6, SHAP 0.46, FastAPI

---

## 2. Intended Use & Clinical Scope
- **Primary Intended Use:** Educational self-screening and personal risk awareness. Estimates the statistical likelihood that an adult belongs to a population cohort reporting diagnosed coronary heart disease or prior myocardial infarction.
- **Out-of-Scope & Prohibited Uses:**
  - **NOT a clinical diagnostic instrument:** Must never replace coronary angiography, electrocardiography, cardiac troponin assays, or physician clinical judgment.
  - **NOT an acute triage engine:** Individuals experiencing acute chest pain, dyspnea, diaphoresis, or presyncope must seek emergency services (911) immediately.
  - **NOT for insurance underwriting or employment eligibility determinations.**

---

## 3. Training & Evaluation Data
- **Data Source:** Official Centers for Disease Control and Prevention (CDC) Behavioral Risk Factor Surveillance System (BRFSS) 2021 Public Dataset.
- **Cohort Size:** Exactly 40,000 valid, non-imputed, stratified records sampled from the complete BRFSS survey.
- **Target Label:** `_MICHD`
  - Positive ($Y=1$): Reported prior myocardial infarction or diagnosed coronary heart disease (8.81% in sample).
  - Negative ($Y=0$): Neither condition reported (91.19% in sample).
- **Partitioning Protocol:**
  - **Training Set (70%):** 28,000 records (stratified by target). Used for 5-fold cross-validation and feature transformation fitting.
  - **Validation Set (15%):** 6,000 records. Used for hyperparameter tuning and isotonic calibration curve fitting.
  - **Holdout Test Set (15%):** 6,000 records. Evaluated once for final reported metrics.
- **Data Leakage Safeguards:**
  - `_MICHD` was strictly isolated from input features.
  - All standard scalers and categorical encoders were fitted exclusively on the 28,000 training records. Zero test data influenced preprocessing parameters.

---

## 4. Model Comparative Benchmarks
Evaluated on the 6,000 holdout test split (Prevalence: 8.80%, Positives: 528):

| Model Architecture | Accuracy | Recall (Sensitivity) | Precision | F1 Score | ROC-AUC | PR-AUC | Brier Calibration |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **HistGradientBoosting (Champion)** | **90.1%** | **46.8%** | **57.6%** | **0.517** | **0.846** | **0.452** | **0.059** |
| Random Forest (Calibrated) | 89.8% | 43.1% | 54.3% | 0.481 | 0.835 | 0.428 | 0.062 |
| Deep Neural Network (Keras MLP) | 89.4% | 42.0% | 49.5% | 0.454 | 0.828 | 0.407 | 0.066 |
| Logistic Regression Baseline | 89.2% | 38.6% | 48.1% | 0.429 | 0.812 | 0.385 | 0.068 |

*Note on Deep Learning:* The Keras Deep Neural Network did NOT outperform tree-based gradient boosting on tabular public health survey data (PR-AUC 0.407 vs 0.452). Tree-based ensembles naturally handled tabular feature interactions, categorical cardinality, and missingness without uncalibrated overconfidence.

---

## 5. Subgroup Fairness & Demographic Parity
Audited across biological sex and age cohorts on the holdout test set:
- **Sex Equity:**
  - Males: Sensitivity 74.2%, Specificity 81.4%, PPV 32.9% (at 0.15 screening threshold)
  - Females: Sensitivity 71.8%, Specificity 83.2%, PPV 24.8% (at 0.15 screening threshold)
  - *Observation:* Recall difference is minimal ($\Delta = 2.4\%$). PPV variance is mathematically governed by Bayes' theorem due to lower true prevalence in the female surveillance sample (7.0% vs 10.8%).
- **Age Cohort Calibration:**
  - Young Adults (18–39): Lower PPV (11.8%) driven by 1.2% base rate; confidence intervals are displayed to prevent alarm.
  - Seniors (65+): High sensitivity (76.2%) with higher false positive rate due to widespread vascular risk factors.

---

## 6. Explainability Methodology (SHAP)
- **Engine:** TreeExplainer with interventional background reference derived from 1,000 stratified training samples.
- **Attribution Format:** Additive log-odds contributions centered around the CDC baseline prevalence ($w_0 = -2.336 \approx 8.81\%$).
- **Top Positive Drivers:** Age category, diagnosed hypertension, diagnosed diabetes, everyday smoking, prior stroke history.
- **Top Negative Drivers:** Regular physical activity, excellent self-rated health, normative BMI, non-smoking status.

---

## 7. Limitations & Caveats
1. **Self-Reported Surveillance:** `_MICHD` derives from telephone interviews; undiagnosed or subclinical coronary disease is miscoded as negative.
2. **Survivorship Bias:** Deceased individuals who suffered fatal infarcts prior to the survey are absent from cross-sectional BRFSS data.
3. **Correlation is Not Causation:** SHAP values represent observational predictive contributions, not counterfactual treatment outcomes.
