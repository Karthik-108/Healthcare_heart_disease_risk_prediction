"""
CardioSense AI - FastAPI Pydantic v2 Validation Schemas
CDC BRFSS 2021 Heart Disease Surveillance Feature Schema
"""

from typing import List, Literal, Optional, Tuple
from pydantic import BaseModel, Field, field_validator


class AssessmentInputSchema(BaseModel):
    """
    Validated user input features derived from CDC BRFSS 2021.
    Strictly validates types, enumerated categories, and biological bounds.
    """
    age_category: Literal[
        'Age 18-24', 'Age 25-29', 'Age 30-34', 'Age 35-39',
        'Age 40-44', 'Age 45-49', 'Age 50-54', 'Age 55-59',
        'Age 60-64', 'Age 65-69', 'Age 70-74', 'Age 75-79',
        'Age 80 or older'
    ] = Field(..., description="CDC 5-year age category (_AGEG5YR)")

    sex: Literal['Male', 'Female'] = Field(..., description="Biological sex (SEXVAR)")

    bmi: float = Field(..., ge=12.0, le=75.0, description="Body Mass Index in kg/m² (_BMI5)")

    smoking_status: Literal[
        'Never smoked',
        'Former smoker',
        'Current smoker - some days',
        'Current smoker - everyday'
    ] = Field(..., description="Tobacco smoking frequency (SMOKDAY2)")

    alcohol_drinking: Literal['No', 'Yes'] = Field(
        ..., description="Heavy drinking: >14 drinks/wk for men, >7 drinks/wk for women (_DRNKWK1)"
    )

    physical_activity: Literal['Yes', 'No'] = Field(
        ..., description="Any leisure physical activity in past 30 days (_TOTINDA)"
    )

    sleep_hours: int = Field(..., ge=1, le=24, description="Average sleep hours per 24h (SLEPTIM1)")

    high_blood_pressure: Literal['Yes', 'No'] = Field(
        ..., description="Ever diagnosed with hypertension (_RFHYPE5)"
    )

    high_cholesterol: Literal['Yes', 'No'] = Field(
        ..., description="Ever diagnosed with hypercholesterolemia (_RFCHOL2)"
    )

    diabetes: Literal['No', 'Yes', 'Borderline / Pre-diabetes', 'Gestational only'] = Field(
        ..., description="Diabetes status (DIABETE4)"
    )

    stroke: Literal['Yes', 'No'] = Field(
        ..., description="Prior history of stroke (CVDSTRK3)"
    )

    general_health: Literal['Excellent', 'Very good', 'Good', 'Fair', 'Poor'] = Field(
        ..., description="Self-rated general health perception (GENHLTH)"
    )

    diff_walking: Literal['Yes', 'No'] = Field(
        ..., description="Serious difficulty walking or climbing stairs (DIFFWALK)"
    )

    disclaimer_accepted: bool = Field(
        ..., description="Mandatory acknowledgment that this tool is not medical advice"
    )

    # Optional fairness / research fields (not used in default inference)
    race_ethnicity: Optional[str] = Field(None, description="Research fairness attribute")
    education_level: Optional[str] = Field(None, description="Research fairness attribute")

    @field_validator('disclaimer_accepted')
    @classmethod
    def validate_disclaimer(cls, v: bool) -> bool:
        if not v:
            raise ValueError("You must acknowledge that this is an educational screening and not medical advice.")
        return v

    class Config:
        extra = "forbid"
        json_schema_extra = {
            "example": {
                "age_category": "Age 55-59",
                "sex": "Male",
                "bmi": 28.4,
                "smoking_status": "Former smoker",
                "alcohol_drinking": "No",
                "physical_activity": "Yes",
                "sleep_hours": 7,
                "high_blood_pressure": "Yes",
                "high_cholesterol": "Yes",
                "diabetes": "Borderline / Pre-diabetes",
                "stroke": "No",
                "general_health": "Good",
                "diff_walking": "No",
                "disclaimer_accepted": True
            }
        }


class ShapFactorSchema(BaseModel):
    feature: str
    label: str
    user_value: str
    shap_value: float
    direction: Literal['increases_risk', 'decreases_risk', 'neutral']
    clinical_context: str


class PreventionAdviceSchema(BaseModel):
    category: str
    title: str
    description: str
    evidence_base: str
    priority: Literal['high', 'medium', 'routine']


class PredictionResponseSchema(BaseModel):
    assessment_id: str
    timestamp: str
    model_version: str
    probability_percent: float
    risk_category: Literal['Low', 'Moderate', 'High']
    confidence_interval: Tuple[float, float]
    baseline_population_risk: float
    shap_factors: List[ShapFactorSchema]
    recommendations: List[PreventionAdviceSchema]
    urgent_warning: bool
    disclaimer: str


class BenchmarkModelSchema(BaseModel):
    model_id: str
    name: str
    architecture: str
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    roc_auc: float
    pr_auc: float
    brier_score: float
    is_champion: bool


class DriftReportSchema(BaseModel):
    timestamp: str
    sample_window_days: int
    total_evaluations: int
    feature_psi: dict
    overall_status: Literal['nominal', 'moderate_drift', 'critical_drift']
    alerts_triggered: List[str]
