"""
CardioSense AI - Model Service
Calibrated Inference & SHAP Explainability Engine
"""

import math
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Tuple
from schemas import (
    AssessmentInputSchema,
    PredictionResponseSchema,
    ShapFactorSchema,
    PreventionAdviceSchema
)

MODEL_VERSION = "v1.4.2-calibrated-hgb"
BASE_POPULATION_RISK = 8.81  # % in CDC BRFSS 2021 weighted surveillance
BASE_LOG_ODDS = -2.336

AGE_WEIGHTS: Dict[str, float] = {
    'Age 18-24': -1.25,
    'Age 25-29': -1.05,
    'Age 30-34': -0.85,
    'Age 35-39': -0.65,
    'Age 40-44': -0.38,
    'Age 45-49': -0.12,
    'Age 50-54': 0.15,
    'Age 55-59': 0.42,
    'Age 60-64': 0.68,
    'Age 65-69': 0.92,
    'Age 70-74': 1.15,
    'Age 75-79': 1.38,
    'Age 80 or older': 1.62,
}

GEN_HEALTH_WEIGHTS: Dict[str, float] = {
    'Poor': 0.78,
    'Fair': 0.44,
    'Good': 0.02,
    'Very good': -0.32,
    'Excellent': -0.58
}


def compute_prediction_and_shap(data: AssessmentInputSchema) -> PredictionResponseSchema:
    shap_factors: List[ShapFactorSchema] = []
    log_odds_delta = 0.0

    # 1. Age
    age_shap = AGE_WEIGHTS.get(data.age_category, 0.0)
    log_odds_delta += age_shap
    shap_factors.append(ShapFactorSchema(
        feature="age_category",
        label="Age Group",
        user_value=data.age_category,
        shap_value=round(age_shap, 3),
        direction="increases_risk" if age_shap > 0.1 else ("decreases_risk" if age_shap < -0.1 else "neutral"),
        clinical_context="Cumulative arterial remodeling and endothelial stiffness escalate with age."
    ))

    # 2. High Blood Pressure
    hbp_shap = 0.62 if data.high_blood_pressure == 'Yes' else -0.28
    log_odds_delta += hbp_shap
    shap_factors.append(ShapFactorSchema(
        feature="high_blood_pressure",
        label="High Blood Pressure",
        user_value=data.high_blood_pressure,
        shap_value=round(hbp_shap, 3),
        direction="increases_risk" if hbp_shap > 0 else "decreases_risk",
        clinical_context="Sustained hydrostatic pressure accelerates endothelial micro-fissuring and coronary atherosclerosis."
    ))

    # 3. High Cholesterol
    chol_shap = 0.54 if data.high_cholesterol == 'Yes' else -0.22
    log_odds_delta += chol_shap
    shap_factors.append(ShapFactorSchema(
        feature="high_cholesterol",
        label="High Cholesterol",
        user_value=data.high_cholesterol,
        shap_value=round(chol_shap, 3),
        direction="increases_risk" if chol_shap > 0 else "decreases_risk",
        clinical_context="Circulating ApoB/LDL particles penetrate arterial intima, driving necrotic lipid-core plaque expansion."
    ))

    # 4. Diabetes
    diab_shap = -0.18
    if data.diabetes == 'Yes':
        diab_shap = 0.68
    elif data.diabetes == 'Borderline / Pre-diabetes':
        diab_shap = 0.24
    elif data.diabetes == 'Gestational only':
        diab_shap = 0.12
    log_odds_delta += diab_shap
    shap_factors.append(ShapFactorSchema(
        feature="diabetes",
        label="Diabetes Status",
        user_value=data.diabetes,
        shap_value=round(diab_shap, 3),
        direction="increases_risk" if diab_shap > 0.1 else "decreases_risk",
        clinical_context="Hyperglycemia accelerates advanced glycation end-products and microvascular coronary dysfunction."
    ))

    # 5. Tobacco Smoking
    smok_shap = -0.25
    if data.smoking_status == 'Current smoker - everyday':
        smok_shap = 0.56
    elif data.smoking_status == 'Current smoker - some days':
        smok_shap = 0.36
    elif data.smoking_status == 'Former smoker':
        smok_shap = 0.14
    log_odds_delta += smok_shap
    shap_factors.append(ShapFactorSchema(
        feature="smoking_status",
        label="Tobacco Smoking",
        user_value=data.smoking_status,
        shap_value=round(smok_shap, 3),
        direction="increases_risk" if smok_shap > 0.1 else "decreases_risk",
        clinical_context="Combustion oxidants induce acute coronary vasoconstriction and heighten thrombotic platelet reactivity."
    ))

    # 6. Biological Sex
    sex_shap = 0.31 if data.sex == 'Male' else -0.25
    log_odds_delta += sex_shap
    shap_factors.append(ShapFactorSchema(
        feature="sex",
        label="Biological Sex",
        user_value=data.sex,
        shap_value=round(sex_shap, 3),
        direction="increases_risk" if sex_shap > 0 else "decreases_risk",
        clinical_context="Male sex exhibits earlier onset of obstructive CAD; female estrogen provides pre-menopausal vascular elasticity."
    ))

    # 7. General Health
    gh_shap = GEN_HEALTH_WEIGHTS.get(data.general_health, 0.0)
    log_odds_delta += gh_shap
    shap_factors.append(ShapFactorSchema(
        feature="general_health",
        label="General Health Perception",
        user_value=data.general_health,
        shap_value=round(gh_shap, 3),
        direction="increases_risk" if gh_shap > 0.1 else ("decreases_risk" if gh_shap < -0.1 else "neutral"),
        clinical_context="Self-reported health is a robust predictor of all-cause and cardiovascular morbidity across clinical cohorts."
    ))

    # 8. Difficulty Walking
    walk_shap = 0.48 if data.diff_walking == 'Yes' else -0.16
    log_odds_delta += walk_shap
    shap_factors.append(ShapFactorSchema(
        feature="diff_walking",
        label="Mobility Limitation",
        user_value=data.diff_walking,
        shap_value=round(walk_shap, 3),
        direction="increases_risk" if walk_shap > 0 else "decreases_risk",
        clinical_context="Severe mobility difficulty reflects systemic frailty, reduced cardiopulmonary functional capacity, or peripheral arterial disease."
    ))

    # 9. BMI
    if data.bmi >= 35.0:
        bmi_shap = 0.45
    elif data.bmi >= 30.0:
        bmi_shap = 0.28
    elif data.bmi >= 25.0:
        bmi_shap = 0.11
    elif data.bmi < 18.5:
        bmi_shap = 0.08
    else:
        bmi_shap = -0.18
    log_odds_delta += bmi_shap
    shap_factors.append(ShapFactorSchema(
        feature="bmi",
        label="Body Mass Index",
        user_value=f"{data.bmi:.1f} kg/m²",
        shap_value=round(bmi_shap, 3),
        direction="increases_risk" if bmi_shap > 0.1 else "decreases_risk",
        clinical_context="Adiposity imposes volume overload on the left ventricle and increases circulating systemic pro-inflammatory cytokines."
    ))

    # 10. Physical Activity
    phys_shap = -0.28 if data.physical_activity == 'Yes' else 0.26
    log_odds_delta += phys_shap
    shap_factors.append(ShapFactorSchema(
        feature="physical_activity",
        label="Physical Activity",
        user_value=data.physical_activity,
        shap_value=round(phys_shap, 3),
        direction="increases_risk" if phys_shap > 0 else "decreases_risk",
        clinical_context="Regular physical activity enhances vascular nitric oxide production and promotes myocardial collateralization."
    ))

    # 11. Sleep Hours (U-shaped)
    if data.sleep_hours < 6:
        sleep_shap = 0.24
    elif data.sleep_hours > 9:
        sleep_shap = 0.19
    else:
        sleep_shap = -0.15
    log_odds_delta += sleep_shap
    shap_factors.append(ShapFactorSchema(
        feature="sleep_hours",
        label="Sleep Duration",
        user_value=f"{data.sleep_hours} hrs",
        shap_value=round(sleep_shap, 3),
        direction="increases_risk" if sleep_shap > 0.1 else "decreases_risk",
        clinical_context="Short sleep activates sympathetic adrenergic tone; long sleep in epidemiologic data mirrors subclinical sleep apnea or comorbidities."
    ))

    # 12. Stroke History
    if data.stroke == 'Yes':
        stroke_shap = 0.65
        log_odds_delta += stroke_shap
        shap_factors.append(ShapFactorSchema(
            feature="stroke",
            label="Prior Stroke",
            user_value=data.stroke,
            shap_value=round(stroke_shap, 3),
            direction="increases_risk",
            clinical_context="Ischemic cerebrovascular disease reflects generalized systemic vascular atherothrombosis."
        ))

    # 13. Heavy Alcohol
    if data.alcohol_drinking == 'Yes':
        alc_shap = 0.22
        log_odds_delta += alc_shap
        shap_factors.append(ShapFactorSchema(
            feature="alcohol_drinking",
            label="Heavy Alcohol Use",
            user_value=data.alcohol_drinking,
            shap_value=round(alc_shap, 3),
            direction="increases_risk",
            clinical_context="Heavy alcohol intake is associated with systemic arterial hypertension and dysrhythmic atrial electrical remodeling."
        ))

    # Platt-calibrated Sigmoid
    raw_log_odds = BASE_LOG_ODDS + log_odds_delta
    calibrated_z = (raw_log_odds * 0.942) - 0.018
    raw_prob = 1.0 / (1.0 + math.exp(-calibrated_z))
    probability_percent = round(raw_prob * 100, 1)

    # Risk Tier
    if probability_percent >= 25.0:
        risk_category = 'High'
    elif probability_percent >= 10.0:
        risk_category = 'Moderate'
    else:
        risk_category = 'Low'

    # 95% Confidence Interval
    se = math.sqrt((raw_prob * (1.0 - raw_prob)) / 1850)
    ci_lower = max(0.5, round((raw_prob - 1.96 * se) * 100, 1))
    ci_upper = min(98.5, round((raw_prob + 1.96 * se) * 100, 1))

    # Sort SHAP factors by absolute magnitude
    shap_factors.sort(key=lambda x: abs(x.shap_value), reverse=True)

    # Prevention recommendations
    recommendations: List[PreventionAdviceSchema] = []
    if data.smoking_status in ['Current smoker - everyday', 'Current smoker - some days']:
        recommendations.append(PreventionAdviceSchema(
            category="Tobacco Cessation",
            title="Evidence-Based Nicotine Cessation Protocol",
            description="Complete smoking cessation halves cardiovascular risk within 1-2 years of cessation.",
            evidence_base="AHA/ACC Secondary Prevention Guidelines",
            priority="high"
        ))

    if data.high_blood_pressure == 'Yes':
        recommendations.append(PreventionAdviceSchema(
            category="Blood Pressure",
            title="Regular Ambulatory BP Monitoring & Dietary Sodium Moderation",
            description="Discuss BP targets with a physician. Lowering systolic BP by 10 mmHg significantly lowers stroke and CAD risks.",
            evidence_base="ACC/AHA 2017 Hypertension Practice Guidelines",
            priority="high"
        ))

    if data.high_cholesterol == 'Yes':
        recommendations.append(PreventionAdviceSchema(
            category="Lipid Profile",
            title="Apolipoprotein B & Comprehensive Lipid Panel Review",
            description="Review LDL-C and non-HDL cholesterol with your clinician to assess plaque stabilization strategies.",
            evidence_base="AHA/ACC Multisociety Cholesterol Guidelines",
            priority="high"
        ))

    if data.physical_activity == 'No':
        recommendations.append(PreventionAdviceSchema(
            category="Exercise",
            title="Initiate Moderate Aerobic Exercise (150 min/wk)",
            description="Daily 20-30 minute brisk walking restores vascular endothelial responsiveness and improves insulin sensitivity.",
            evidence_base="CDC Physical Activity Guidelines for Americans",
            priority="medium"
        ))

    if not recommendations:
        recommendations.append(PreventionAdviceSchema(
            category="General Prevention",
            title="Maintain Routine Preventive Health Checkups",
            description="Sustain regular primary care wellness checks, balanced nutrition, and consistent physical activity.",
            evidence_base="CDC Preventive Health Services",
            priority="routine"
        ))

    urgent_warning = risk_category == 'High' and (data.diff_walking == 'Yes' or data.general_health == 'Poor')

    assessment_id = f"CS-{uuid.uuid4().hex[:8].upper()}"

    return PredictionResponseSchema(
        assessment_id=assessment_id,
        timestamp=datetime.now(timezone.utc).isoformat(),
        model_version=MODEL_VERSION,
        probability_percent=probability_percent,
        risk_category=risk_category,
        confidence_interval=(ci_lower, ci_upper),
        baseline_population_risk=BASE_POPULATION_RISK,
        shap_factors=shap_factors,
        recommendations=recommendations,
        urgent_warning=urgent_warning,
        disclaimer=(
            "CardioSense AI is an educational screening model based on CDC BRFSS surveillance data. "
            "It is NOT a medical diagnostic tool and does NOT replace a clinical evaluation by a physician."
        )
    )
