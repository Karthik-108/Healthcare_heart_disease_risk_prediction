# CardioSense AI — Architecture & Technical Design

This document details the software architecture, data flow, ML pipeline, and MLOps surveillance design for **CardioSense AI**.

---

## 1. System Architecture Overview

```
                        +---------------------------------------------+
                        |           CardioSense AI Client             |
                        |   (React 19 + TypeScript + Tailwind CSS)    |
                        +----------------------+----------------------+
                                               |
                                     HTTPS / REST JSON
                                               v
                        +---------------------------------------------+
                        |            FastAPI API Gateway              |
                        |      (Rate Limiting, Pydantic v2, CORS)     |
                        +----------------------+----------------------+
                                               |
                 +-----------------------------+-----------------------------+
                 |                                                           |
                 v                                                           v
  +-------------------------------+                         +----------------------------------+
  |   Model Inference & SHAP      |                         |      Persistence & MLOps         |
  |  - HistGradientBoosting v1.4.2|                         |  - PostgreSQL 16 (User Profiles) |
  |  - Isotonic Probability Calib |                         |  - PSI Feature Drift Tracker     |
  |  - TreeExplainer Attribution  |                         |  - Prometheus Scraper & Metrics  |
  +-------------------------------+                         +----------------------------------+
```

---

## 2. Machine Learning Pipeline Architecture

```
[ CDC BRFSS 2021 Raw Data (~438,000 Records) ]
                    |
                    v
[ Data Cleaning Engine (data_cleaning.py) ]
  - Filter 77/99 ("Don't Know", "Refused", Missing)
  - Map _MICHD -> Binary (1: MI/CHD, 0: None)
  - Validate biological ranges (BMI 12-75, Sleep 1-24)
                    |
                    v
[ Stratified Sampling (40,000 Records, 8.81% Prevalence) ]
                    |
                    v
[ Stratified Split: Train 70% (28k), Val 15% (6k), Test 15% (6k) ]
                    |
        +-----------+-----------+
        |                       |
        v                       v
[ Preprocessing Fit ]   [ 5-Fold Stratified CV ]
  - StandardScaler        - Train 4 Architectures:
  - OneHotEncoder           1. Logistic Regression
  (Train data only)         2. Random Forest
                            3. HistGradientBoosting (Selected)
                            4. Keras Deep Neural Network
                                |
                                v
                [ Probability Calibration ]
                  - Isotonic Regression / Platt Scaling
                                |
                                v
                [ Model Evaluation & Fairness Audit ]
                  - PR-AUC, ROC-AUC, Brier score
                  - Equal Opportunity by Age & Sex
                                |
                                v
                [ Production Artifact Staging ]
```

---

## 3. MLOps Surveillance & Drift Detection

CardioSense AI continuously tracks serving traffic against the 40,000 CDC training distribution using the **Population Stability Index (PSI)**:

$$\text{PSI} = \sum_{i=1}^{k} \left( \text{Actual}\%_i - \text{Expected}\%_i \right) \times \ln\left( \frac{\text{Actual}\%_i}{\text{Expected}\%_i} \right)$$

- **PSI Thresholds:**
  - $\text{PSI} < 0.10$: Nominal stability; no action needed.
  - $0.10 \le \text{PSI} \le 0.20$: Moderate shift; trigger automated warning.
  - $\text{PSI} > 0.20$: Significant population drift; flags alert for review.

### Human-in-the-Loop Retraining Policy
Under healthcare governance standards, **automated model re-deployment is strictly blocked**. Retrained candidate models must pass:
1. Shadow evaluation on holdout surveillance validation splits.
2. Subgroup parity verification (Recall difference $< 5\%$).
3. Explicit administrative sign-off before artifact promotion.

---

## 4. Security & Privacy Safeguards
- **Client Session Isolation:** Assessments are segregated per session; users cannot access other records.
- **Client-Side Draft Storage:** Incomplete forms are saved to browser `localStorage` and never transmitted prematurely.
- **Right to Erasure ("Delete My Data"):** Complete deletion of historical assessments is supported both per-record and globally.
- **No Target Leakage:** No acute diagnostic markers (troponin, angiograms, emergency medications) are solicited or accepted by the API.
