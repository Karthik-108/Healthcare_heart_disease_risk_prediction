# CDC BRFSS 2021 Data Dictionary — CardioSense AI

This document provides exhaustive documentation of all variables used in CardioSense AI, derived from the Centers for Disease Control and Prevention (CDC) Behavioral Risk Factor Surveillance System (BRFSS) 2021 Survey.

---

## 1. Primary Target Variable (Supervised Outcome)

### `_MICHD` — Reported Myocardial Infarction or Coronary Heart Disease
- **CDC Definition:** Derived variable identifying respondents who ever reported having coronary heart disease (CVDCRHD4) or heart attack/myocardial infarction (CVDINFR4).
- **Survey Question:** *"Has a doctor, nurse, or other health professional ever told you that you had: 1. A heart attack, also called a myocardial infarction? 2. Angina or coronary heart disease?"*
- **Response Options:**
  - `1`: Reported condition (diagnosed prior myocardial infarction or coronary heart disease)
  - `2`: Did not report condition (neither condition reported)
  - `BLANK` / `77` / `99`: Don't know / Refused / Missing (filtered out during data cleaning)
- **Model Recoding:** Binary target ($1 = \text{Reported}$, $0 = \text{Not Reported}$).
- **Prevalence in Clean 40,000 Sample:** 8.81% (3,524 positive cases).
- **Leakage Safeguard:** Strictly excluded from feature inputs.

---

## 2. Demographic Input Features

### `_AGEG5YR` — Fourteen-Level Age Category
- **CDC Question:** Reported age in 5-year cohorts.
- **Categories:** `Age 18-24`, `Age 25-29`, `Age 30-34`, `Age 35-39`, `Age 40-44`, `Age 45-49`, `Age 50-54`, `Age 55-59`, `Age 60-64`, `Age 65-69`, `Age 70-74`, `Age 75-79`, `Age 80 or older`.
- **Clinical Rationale:** Non-modifiable risk factor; cumulative vascular calcification and intimal thickening increase exponentially with advancing decades.

### `SEXVAR` — Sex of Respondent
- **CDC Question:** *"Are you male or female?"*
- **Categories:** `Male` (1), `Female` (2).
- **Clinical Rationale:** Biological sex determines differences in sex hormones (endogenous estrogen vascular protection), microvascular vs. macrovascular CAD presentation, and age-of-onset distributions.

---

## 3. Anthropometric & Clinical Features

### `_BMI5` — Calculated Body Mass Index (BMI)
- **CDC Question:** Computed from self-reported height and weight in kilograms divided by height in meters squared (with 2 implied decimal places).
- **Valid Bounds:** 12.0 to 75.0 kg/m².
- **Categories:**
  - Underweight: $< 18.5$
  - Normal weight: $18.5 - 24.9$
  - Overweight: $25.0 - 29.9$
  - Obese Class I–III: $\ge 30.0$
- **Clinical Rationale:** Adiposity causes left ventricular volume and pressure overload, insulin resistance, and elevated circulating levels of pro-inflammatory cytokines (IL-6, TNF-$\alpha$).

### `_RFHYPE5` — High Blood Pressure Awareness
- **CDC Question:** *"Have you ever been told by a doctor, nurse, or other health professional that you have high blood pressure?"*
- **Categories:** `No` (1), `Yes` (2).
- **Clinical Rationale:** Hypertension produces chronic mechanical shear stress on arterial walls, damaging the endothelial glycocalyx and promoting atherosclerotic plaque development.

### `_RFCHOL2` — High Blood Cholesterol Awareness
- **CDC Question:** *"Have you ever been told by a doctor, nurse or other health professional that your blood cholesterol is high?"*
- **Categories:** `No` (1), `Yes` (2).
- **Clinical Rationale:** Elevated ApoB and low-density lipoprotein (LDL) particles are the causative agents of coronary intimal lipid accumulation and atheroma growth.

### `DIABETE4` — Diabetes Diagnosis
- **CDC Question:** *"Have you ever been told by a doctor that you have diabetes?"*
- **Categories:** `No`, `Yes`, `Borderline / Pre-diabetes`, `Gestational only`.
- **Clinical Rationale:** Chronic hyperglycemia accelerates vascular stiffening, non-enzymatic glycation of arterial matrix proteins, and coronary microvascular dysfunction.

### `CVDSTRK3` — Stroke Diagnosis
- **CDC Question:** *"Have you ever been told you had a stroke?"*
- **Categories:** `No` (2), `Yes` (1).
- **Clinical Rationale:** Ischemic stroke and coronary artery disease share systemic atherosclerotic and atherothrombotic pathophysiological mechanisms.

---

## 4. Lifestyle & Behavioral Features

### `SMOKDAY2` — Frequency of Days Now Smoking
- **CDC Question:** *"Do you now smoke cigarettes everyday, some days, or not at all?"* (paired with SMOKE100 lifetime threshold).
- **Categories:** `Never smoked`, `Former smoker`, `Current smoker - some days`, `Current smoker - everyday`.
- **Clinical Rationale:** Combustion products cause oxidative endothelial stress, trigger coronary vasospasm, and increase circulating platelet reactivity and fibrinogen levels.

### `_DRNKWK1` — Calculated Total Drinks Per Week
- **CDC Question:** Calculated volume of alcohol consumed per week.
- **Categories:** Non-drinker / Moderate, Heavy drinker ($>14$ drinks/wk for men, $>7$ drinks/wk for women).
- **Clinical Rationale:** Chronic high-dose alcohol consumption increases myocardial toxicity, elevates resting blood pressure, and induces supraventricular arrhythmias (e.g. atrial fibrillation).

### `_TOTINDA` — Leisure-Time Physical Activity
- **CDC Question:** *"During the past month, other than your regular job, did you participate in any physical activities or exercises such as running, calisthenics, golf, gardening, or walking for exercise?"*
- **Categories:** `Yes` (1), `No` (2).
- **Clinical Rationale:** Regular aerobic activity improves coronary collateral vascular flow, lowers resting heart rate and arterial stiffness, and improves glycemic regulation.

### `SLEPTIM1` — Sleep Hours per 24-Hour Period
- **CDC Question:** *"On average, how many hours of sleep do you get in a 24-hour period?"*
- **Categories:** Integer hours between 1 and 24.
- **Clinical Rationale:** Exhibits a validated U-shaped risk curve; short sleep ($<6$ hours) elevates nocturnal sympathetic activity and nocturnal blood pressure non-dipping, while prolonged sleep ($>9$ hours) frequently correlates with systemic inflammation or sleep apnea.

---

## 5. Functional & General Health

### `GENHLTH` — General Health Rating
- **CDC Question:** *"Would you say that in general your health is: Excellent, Very good, Good, Fair, or Poor?"*
- **Categories:** `Excellent`, `Very good`, `Good`, `Fair`, `Poor`.
- **Clinical Rationale:** Self-rated health integrates multisystem physiological reserve and subclinical symptom burdens, functioning as a validated predictor of prospective cardiovascular mortality.

### `DIFFWALK` — Difficulty Walking or Climbing Stairs
- **CDC Question:** *"Do you have serious difficulty walking or climbing stairs?"*
- **Categories:** `No` (2), `Yes` (1).
- **Clinical Rationale:** Functional mobility impairment identifies individuals with severe frailty, symptomatic peripheral artery disease, or reduced functional cardiopulmonary reserve.
