/**
 * CDC BRFSS 2021 Data Dictionary
 * Behavioral Risk Factor Surveillance System
 */

export interface VariableMeta {
  code: string;
  name: string;
  category: 'Target' | 'Demographic' | 'Lifestyle' | 'Clinical' | 'General Health' | 'Fairness Attribute';
  questionText: string;
  responseOptions: { code: string; label: string; meaning: string }[];
  clinicalRationale: string;
  leakageStatus: 'Target Label' | 'Clean Input (Non-leaking)' | 'Fairness Audit Only';
}

export const CDC_BRFSS_DATA_DICTIONARY: VariableMeta[] = [
  {
    code: '_MICHD',
    name: 'Reported Myocardial Infarction or Coronary Heart Disease',
    category: 'Target',
    questionText: 'Derived variable: Respondents who ever reported having coronary heart disease (CVDCRHD4) or myocardial infarction/heart attack (CVDINFR4).',
    responseOptions: [
      { code: '1', label: 'Reported condition', meaning: 'Diagnosed prior myocardial infarction or coronary heart disease' },
      { code: '2', label: 'Did not report condition', meaning: 'Neither condition reported (converted to binary 0)' }
    ],
    clinicalRationale: 'Defines the primary binary surveillance target (1 = heart disease reported, 0 = not reported). Used strictly for supervised training and evaluation; never included as an input feature.',
    leakageStatus: 'Target Label'
  },
  {
    code: '_AGEG5YR',
    name: 'Fourteen-level age category',
    category: 'Demographic',
    questionText: 'Reported age in 5-year intervals from 18 to 80+ years.',
    responseOptions: [
      { code: '1', label: 'Age 18 to 24', meaning: 'Young adult baseline' },
      { code: '2-7', label: 'Age 25 to 54', meaning: 'Adult early-to-mid career' },
      { code: '8-12', label: 'Age 55 to 79', meaning: 'Older adult' },
      { code: '13', label: 'Age 80 or older', meaning: 'Octogenarian and nonagenarian cohort' },
      { code: '14', label: 'Don\'t know/Refused', meaning: 'Excluded during 40,000 stratified data cleaning' }
    ],
    clinicalRationale: 'Age is the strongest non-modifiable cardiovascular risk factor due to cumulative vascular remodeling and endothelial senescence.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: 'SEXVAR',
    name: 'Sex of Respondent',
    category: 'Demographic',
    questionText: 'Are you male or female?',
    responseOptions: [
      { code: '1', label: 'Male', meaning: 'Male biological sex' },
      { code: '2', label: 'Female', meaning: 'Female biological sex' }
    ],
    clinicalRationale: 'Biological sex influences age of onset, ischemic presentation, and hormonal protection prior to menopause.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: '_BMI5',
    name: 'Body Mass Index (BMI)',
    category: 'Clinical',
    questionText: 'Computed from reported height and weight in kilograms divided by height in meters squared (with two implied decimals).',
    responseOptions: [
      { code: '<18.5', label: 'Underweight', meaning: 'BMI less than 18.5' },
      { code: '18.5 - 24.9', label: 'Normal Weight', meaning: 'Standard reference interval' },
      { code: '25.0 - 29.9', label: 'Overweight', meaning: 'Elevated adipose metabolic burden' },
      { code: '>=30.0', label: 'Obese', meaning: 'Class I-III obesity with adipokine elevation' }
    ],
    clinicalRationale: 'Adiposity elevates left ventricular workload, promotes systemic inflammation, and accelerates atherogenesis.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: 'SMOKDAY2',
    name: 'Frequency of Days Now Smoking',
    category: 'Lifestyle',
    questionText: 'Do you now smoke cigarettes everyday, some days, or not at all?',
    responseOptions: [
      { code: '1', label: 'Current - Everyday', meaning: 'Daily exposure to combustion toxicants and nicotine' },
      { code: '2', label: 'Current - Some days', meaning: 'Intermittent active tobacco consumption' },
      { code: '3', label: 'Former smoker', meaning: 'History of >=100 cigarettes, currently quit' },
      { code: '4', label: 'Never smoked', meaning: '<100 cigarettes lifetime' }
    ],
    clinicalRationale: 'Tobacco combustion causes endothelial injury, platelet hyper-reactivity, coronary vasoconstriction, and carboxyhemoglobinemia.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: '_DRNKWK1',
    name: 'Calculated Total Number of Alcoholic Drinks per Week',
    category: 'Lifestyle',
    questionText: 'Calculated weekly drink consumption based on frequency and typical volume.',
    responseOptions: [
      { code: '0', label: 'Non-drinker / Moderate', meaning: '<=14 drinks/wk (men) or <=7 drinks/wk (women)' },
      { code: '1', label: 'Heavy drinker', meaning: '>14 drinks/wk (men) or >7 drinks/wk (women)' }
    ],
    clinicalRationale: 'Excessive chronic ethanol intake induces alcoholic cardiomyopathy, elevated blood pressure, and supraventricular arrhythmias.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: '_TOTINDA',
    name: 'Leisure-Time Physical Activity Status',
    category: 'Lifestyle',
    questionText: 'During the past month, other than your regular job, did you participate in any physical activities or exercises?',
    responseOptions: [
      { code: '1', label: 'Yes', meaning: 'Had physical activity or exercise in past 30 days' },
      { code: '2', label: 'No', meaning: 'No leisure-time physical activity in past 30 days' }
    ],
    clinicalRationale: 'Aerobic activity improves coronary collateralization, decreases arterial stiffness, and enhances insulin sensitivity.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: 'DIABETE4',
    name: 'Diabetes Diagnosis',
    category: 'Clinical',
    questionText: 'Have you ever been told by a doctor that you have diabetes?',
    responseOptions: [
      { code: '1', label: 'Yes', meaning: 'Diagnosed diabetes (Type 1 or 2)' },
      { code: '2', label: 'Gestational only', meaning: 'Diagnosed solely during pregnancy' },
      { code: '3', label: 'No', meaning: 'No reported diabetes' },
      { code: '4', label: 'Borderline / Pre-diabetes', meaning: 'Impaired fasting glucose or pre-diabetes' }
    ],
    clinicalRationale: 'Hyperglycemia accelerates advanced glycation end-products (AGEs), vascular micro-calcification, and coronary atherosclerosis.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: '_RFHYPE5',
    name: 'High Blood Pressure Awareness',
    category: 'Clinical',
    questionText: 'Adults who have been told they have high blood pressure by a doctor, nurse, or other health professional.',
    responseOptions: [
      { code: '1', label: 'No', meaning: 'No diagnosed hypertension' },
      { code: '2', label: 'Yes', meaning: 'Diagnosed hypertension' }
    ],
    clinicalRationale: 'Sustained shear stress damages coronary endothelium, accelerates plaque buildup, and increases myocardial oxygen demand.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: '_RFCHOL2',
    name: 'High Cholesterol Awareness',
    category: 'Clinical',
    questionText: 'Adults who have had their cholesterol checked and have been told it was high.',
    responseOptions: [
      { code: '1', label: 'No', meaning: 'No diagnosed hypercholesterolemia' },
      { code: '2', label: 'Yes', meaning: 'Diagnosed hypercholesterolemia' }
    ],
    clinicalRationale: 'ApoB/LDL particle retention in the arterial intima is the biological prerequisite for atherosclerotic plaque formation.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: 'GENHLTH',
    name: 'General Health Rating',
    category: 'General Health',
    questionText: 'Would you say that in general your health is: Excellent, Very good, Good, Fair, or Poor?',
    responseOptions: [
      { code: '1', label: 'Excellent', meaning: 'Optimal subjective health' },
      { code: '2', label: 'Very good', meaning: 'Above-average health' },
      { code: '3', label: 'Good', meaning: 'Average vitality' },
      { code: '4', label: 'Fair', meaning: 'Mild-to-moderate functional impairment' },
      { code: '5', label: 'Poor', meaning: 'Significant chronic health burden' }
    ],
    clinicalRationale: 'Self-rated health is a validated, robust predictor of all-cause and cardiovascular mortality independent of clinical biomarkers.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: 'SLEPTIM1',
    name: 'Hours of Sleep per 24-Hour Period',
    category: 'Lifestyle',
    questionText: 'On average, how many hours of sleep do you get in a 24-hour period?',
    responseOptions: [
      { code: '1-24', label: '1 to 24 Hours', meaning: 'Reported integer sleep hours; U-shaped risk curve (<6h and >9h elevated)' }
    ],
    clinicalRationale: 'Chronic short sleep induces sympathetic overactivation, cortisol secretion, and systemic inflammation; long sleep often reflects chronic systemic comorbidity.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: 'DIFFWALK',
    name: 'Difficulty Walking or Climbing Stairs',
    category: 'General Health',
    questionText: 'Do you have serious difficulty walking or climbing stairs?',
    responseOptions: [
      { code: '1', label: 'Yes', meaning: 'Serious mobility limitation' },
      { code: '2', label: 'No', meaning: 'No severe walking limitation' }
    ],
    clinicalRationale: 'Captures functional capacity, peripheral vascular disease symptoms, and severe frailty associated with heart disease.',
    leakageStatus: 'Clean Input (Non-leaking)'
  },
  {
    code: 'CVDSTRK3',
    name: 'Ever Diagnosed with a Stroke',
    category: 'Clinical',
    questionText: 'Have you ever been told you had a stroke?',
    responseOptions: [
      { code: '1', label: 'Yes', meaning: 'Prior cerebrovascular accident' },
      { code: '2', label: 'No', meaning: 'No prior diagnosed stroke' }
    ],
    clinicalRationale: 'Cerebrovascular and coronary disease share systemic atherothrombotic pathophysiology.',
    leakageStatus: 'Clean Input (Non-leaking)'
  }
];
