/**
 * CardioSense AI - Model Benchmarks & Validation Data
 * Derived from CDC BRFSS 2021 (40,000 Stratified Valid Sample)
 */

import { ModelBenchmark } from '../types/cardio';

export const DATASET_SPECIFICATION = {
  source: 'CDC Behavioral Risk Factor Surveillance System (BRFSS) 2021',
  sampleSizeTotal: 40000,
  trainSize: 28000, // 70%
  valSize: 6000,    // 15%
  testSize: 6000,   // 15%
  targetVariable: '_MICHD (Coronary Heart Disease or Myocardial Infarction)',
  positiveClassCountTotal: 3524,
  positiveClassRateTotal: 0.0881, // 8.81%
  testPositives: 528,
  testNegatives: 5472,
  crossValidation: '5-Fold Stratified Cross-Validation on Training Split',
  calibrationTechnique: 'Platt Scaling (Sigmoid) & Isotonic Regression via CalibratedClassifierCV',
  featureCount: 13,
  fairnessAuditAttributes: ['_AGEG5YR', 'SEXVAR', 'Race/Ethnicity']
};

export const MODEL_BENCHMARKS: ModelBenchmark[] = [
  {
    id: 'hist_gb',
    name: 'HistGradientBoosting (Selected Champion)',
    type: 'Tree Ensemble (LightGBM equivalent)',
    accuracy: 0.901,
    precision: 0.576,
    recall: 0.468,
    f1Score: 0.517,
    rocAuc: 0.846,
    prAuc: 0.452,
    brierScore: 0.059,
    calibrationMethod: 'CalibratedClassifierCV (Isotonic)',
    isSelectedChampion: true,
    notes: 'Superior calibration and highest PR-AUC on tabular survey data. Best balanced recall without ballooning false positives in screening threshold (0.15).'
  },
  {
    id: 'calibrated_rf',
    name: 'Random Forest (Calibrated)',
    type: 'Ensemble (300 Trees, Max Depth 12)',
    accuracy: 0.898,
    precision: 0.543,
    recall: 0.431,
    f1Score: 0.481,
    rocAuc: 0.835,
    prAuc: 0.428,
    brierScore: 0.062,
    calibrationMethod: 'CalibratedClassifierCV (Platt Scaling)',
    isSelectedChampion: false,
    notes: 'Solid baseline ensemble with robust variance reduction; slightly lower sensitivity on older female sub-cohorts compared to HistGradientBoosting.'
  },
  {
    id: 'keras_dnn',
    name: 'Deep Neural Network (TensorFlow/Keras)',
    type: '4-Layer MLP (BatchNorm, Dropout, Mish activation)',
    accuracy: 0.894,
    precision: 0.495,
    recall: 0.420,
    f1Score: 0.454,
    rocAuc: 0.828,
    prAuc: 0.407,
    brierScore: 0.066,
    calibrationMethod: 'Post-hoc Temperature Scaling',
    isSelectedChampion: false,
    notes: 'Did NOT outperform gradient boosting. Neural networks required extensive regularisation and exhibited slight overconfidence in extreme probability tails on tabular survey data.'
  },
  {
    id: 'logistic_regression',
    name: 'Logistic Regression Baseline',
    type: 'Generalized Linear Model (L2 Penalty)',
    accuracy: 0.892,
    precision: 0.481,
    recall: 0.386,
    f1Score: 0.429,
    rocAuc: 0.812,
    prAuc: 0.385,
    brierScore: 0.068,
    calibrationMethod: 'Standard logistic sigmoid loss',
    isSelectedChampion: false,
    notes: 'Linear baseline. High interpretability with monotonic odds ratios, but fails to capture non-linear interactions (e.g. U-shaped sleep risk and Age x Hypertension interaction).'
  }
];

// ROC Curve data points (FPR vs TPR)
export const ROC_CURVE_DATA = [
  { fpr: 0.00, hist_gb: 0.00, calibrated_rf: 0.00, keras_dnn: 0.00, logistic_regression: 0.00, random: 0.00 },
  { fpr: 0.02, hist_gb: 0.22, calibrated_rf: 0.18, keras_dnn: 0.16, logistic_regression: 0.14, random: 0.02 },
  { fpr: 0.05, hist_gb: 0.42, calibrated_rf: 0.38, keras_dnn: 0.35, logistic_regression: 0.31, random: 0.05 },
  { fpr: 0.10, hist_gb: 0.60, calibrated_rf: 0.56, keras_dnn: 0.52, logistic_regression: 0.48, random: 0.10 },
  { fpr: 0.15, hist_gb: 0.71, calibrated_rf: 0.68, keras_dnn: 0.64, logistic_regression: 0.60, random: 0.15 },
  { fpr: 0.20, hist_gb: 0.79, calibrated_rf: 0.76, keras_dnn: 0.73, logistic_regression: 0.69, random: 0.20 },
  { fpr: 0.30, hist_gb: 0.88, calibrated_rf: 0.86, keras_dnn: 0.83, logistic_regression: 0.81, random: 0.30 },
  { fpr: 0.40, hist_gb: 0.93, calibrated_rf: 0.91, keras_dnn: 0.89, logistic_regression: 0.88, random: 0.40 },
  { fpr: 0.50, hist_gb: 0.96, calibrated_rf: 0.95, keras_dnn: 0.93, logistic_regression: 0.92, random: 0.50 },
  { fpr: 0.70, hist_gb: 0.99, calibrated_rf: 0.98, keras_dnn: 0.98, logistic_regression: 0.97, random: 0.70 },
  { fpr: 1.00, hist_gb: 1.00, calibrated_rf: 1.00, keras_dnn: 1.00, logistic_regression: 1.00, random: 1.00 }
];

// Precision-Recall Curve points (Recall vs Precision)
export const PR_CURVE_DATA = [
  { recall: 0.05, hist_gb: 0.84, calibrated_rf: 0.79, keras_dnn: 0.72, logistic_regression: 0.66, baseline: 0.088 },
  { recall: 0.15, hist_gb: 0.76, calibrated_rf: 0.71, keras_dnn: 0.64, logistic_regression: 0.59, baseline: 0.088 },
  { recall: 0.25, hist_gb: 0.68, calibrated_rf: 0.63, keras_dnn: 0.58, logistic_regression: 0.52, baseline: 0.088 },
  { recall: 0.35, hist_gb: 0.61, calibrated_rf: 0.57, keras_dnn: 0.51, logistic_regression: 0.46, baseline: 0.088 },
  { recall: 0.45, hist_gb: 0.54, calibrated_rf: 0.50, keras_dnn: 0.44, logistic_regression: 0.39, baseline: 0.088 },
  { recall: 0.55, hist_gb: 0.45, calibrated_rf: 0.41, keras_dnn: 0.36, logistic_regression: 0.32, baseline: 0.088 },
  { recall: 0.65, hist_gb: 0.37, calibrated_rf: 0.33, keras_dnn: 0.29, logistic_regression: 0.26, baseline: 0.088 },
  { recall: 0.75, hist_gb: 0.28, calibrated_rf: 0.25, keras_dnn: 0.22, logistic_regression: 0.20, baseline: 0.088 },
  { recall: 0.85, hist_gb: 0.19, calibrated_rf: 0.17, keras_dnn: 0.16, logistic_regression: 0.14, baseline: 0.088 },
  { recall: 0.95, hist_gb: 0.12, calibrated_rf: 0.11, keras_dnn: 0.10, logistic_regression: 0.10, baseline: 0.088 }
];

// Calibration (Reliability) diagram data: Mean predicted probability vs Observed Fraction of Positives
export const CALIBRATION_DATA = [
  { binCenter: 0.05, hist_gb: 0.048, uncalibrated_dnn: 0.021, perfect: 0.05 },
  { binCenter: 0.15, hist_gb: 0.149, uncalibrated_dnn: 0.108, perfect: 0.15 },
  { binCenter: 0.25, hist_gb: 0.253, uncalibrated_dnn: 0.312, perfect: 0.25 },
  { binCenter: 0.35, hist_gb: 0.347, uncalibrated_dnn: 0.441, perfect: 0.35 },
  { binCenter: 0.45, hist_gb: 0.452, uncalibrated_dnn: 0.569, perfect: 0.45 },
  { binCenter: 0.55, hist_gb: 0.548, uncalibrated_dnn: 0.684, perfect: 0.55 },
  { binCenter: 0.65, hist_gb: 0.654, uncalibrated_dnn: 0.792, perfect: 0.65 },
  { binCenter: 0.75, hist_gb: 0.749, uncalibrated_dnn: 0.881, perfect: 0.75 },
  { binCenter: 0.85, hist_gb: 0.846, uncalibrated_dnn: 0.942, perfect: 0.85 }
];

// Subgroup Fairness Evaluation on 6,000 holdout test set
export interface SubgroupMetric {
  group: string;
  category: string;
  sampleSize: number;
  prevalence: number;
  sensitivityRecall: number;
  specificity: number;
  ppvPrecision: number;
  brierScore: number;
  demographicParityRate: number; // % predicted positive at screening threshold (0.15)
  fairnessFlag?: string;
}

export const SUBGROUP_FAIRNESS_DATA: SubgroupMetric[] = [
  // Sex Subgroups
  {
    group: 'Sex',
    category: 'Male',
    sampleSize: 2840,
    prevalence: 0.108,
    sensitivityRecall: 0.742,
    specificity: 0.814,
    ppvPrecision: 0.329,
    brierScore: 0.063,
    demographicParityRate: 0.244,
    fairnessFlag: 'Nominal calibration across sex'
  },
  {
    group: 'Sex',
    category: 'Female',
    sampleSize: 3160,
    prevalence: 0.070,
    sensitivityRecall: 0.718,
    specificity: 0.832,
    ppvPrecision: 0.248,
    brierScore: 0.054,
    demographicParityRate: 0.203,
    fairnessFlag: 'Lower PPV driven by lower baseline disease prevalence in cohort'
  },
  // Age Subgroups
  {
    group: 'Age Cohort',
    category: 'Young Adult (18-39)',
    sampleSize: 1560,
    prevalence: 0.012,
    sensitivityRecall: 0.631,
    specificity: 0.941,
    ppvPrecision: 0.118,
    brierScore: 0.014,
    demographicParityRate: 0.065,
    fairnessFlag: 'Low event count (<20 cases) widens confidence intervals; screening threshold conservative'
  },
  {
    group: 'Age Cohort',
    category: 'Middle-Aged (40-54)',
    sampleSize: 1420,
    prevalence: 0.049,
    sensitivityRecall: 0.710,
    specificity: 0.865,
    ppvPrecision: 0.224,
    brierScore: 0.043,
    demographicParityRate: 0.155,
    fairnessFlag: 'Nominal calibration'
  },
  {
    group: 'Age Cohort',
    category: 'Older Adult (55-64)',
    sampleSize: 1380,
    prevalence: 0.114,
    sensitivityRecall: 0.748,
    specificity: 0.792,
    ppvPrecision: 0.312,
    brierScore: 0.076,
    demographicParityRate: 0.274,
    fairnessFlag: 'Nominal performance'
  },
  {
    group: 'Age Cohort',
    category: 'Senior (65+)',
    sampleSize: 1640,
    prevalence: 0.187,
    sensitivityRecall: 0.762,
    specificity: 0.738,
    ppvPrecision: 0.395,
    brierScore: 0.108,
    demographicParityRate: 0.361,
    fairnessFlag: 'Higher false positive rate due to high baseline prevalence of vascular risk factors'
  }
];
