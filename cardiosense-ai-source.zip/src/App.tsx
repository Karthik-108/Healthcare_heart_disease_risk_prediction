/**
 * CardioSense AI - Core Application Entry Point
 * Educational Cardiovascular Risk Screening Platform
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { LandingHero } from './components/LandingHero';
import { AssessmentForm } from './components/AssessmentForm';
import { PredictionView } from './components/PredictionView';
import { ModelTransparency } from './components/ModelTransparency';
import { MLOpsDashboard } from './components/MLOpsDashboard';
import { UserDashboard } from './components/UserDashboard';
import { DataDictionaryView } from './components/DataDictionaryView';
import {
  AssessmentFormData,
  PredictionResult,
  SavedAssessment
} from './types/cardio';
import { calculateCardioPrediction } from './services/cardioModelEngine';
import { Heart, ShieldCheck, AlertCircle, FileText, Activity } from 'lucide-react';

const HISTORY_STORAGE_KEY = 'cardiosense_user_assessments_v1';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [latestResult, setLatestResult] = useState<PredictionResult | null>(null);
  const [history, setHistory] = useState<SavedAssessment[]>(() => {
    const saved = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return [];
      }
    }
    // Seed initial demo assessment for longitudinal trend demonstration
    const initialSeed: SavedAssessment = {
      id: 'CS-DEMO-SEED-01',
      userId: 'user_active_01',
      userName: 'Active Patient Session',
      timestamp: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days ago
      modelVersion: 'v1.4.1-calibrated-rf',
      probabilityPercent: 21.4,
      riskCategory: 'Moderate',
      inputs: {
        ageCategory: 'Age 55-59',
        sex: 'Male',
        heightFeet: 5,
        heightInches: 10,
        weightLbs: 210,
        bmi: 30.1,
        smokingStatus: 'Former smoker',
        alcoholDrinking: 'No',
        physicalActivity: 'No',
        sleepHours: 6,
        highBloodPressure: 'Yes',
        highCholesterol: 'Yes',
        diabetes: 'Borderline / Pre-diabetes',
        stroke: 'No',
        generalHealth: 'Fair',
        diffWalking: 'No',
        disclaimerAccepted: true
      },
      summaryHighlights: ['Age: 55-59', 'High Blood Pressure', 'Physical Inactivity']
    };
    return [initialSeed];
  });

  const [userEmail] = useState<string>('patient.session@cardiosense.internal');

  // Sync history to localStorage
  useEffect(() => {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
  }, [history]);

  const handleAssessmentSubmit = (data: AssessmentFormData) => {
    const prediction = calculateCardioPrediction(data);
    setLatestResult(prediction);
    setCurrentTab('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveToHistory = (assessment: SavedAssessment) => {
    setHistory(prev => [assessment, ...prev.filter(item => item.id !== assessment.id)]);
  };

  const handleDeleteAssessment = (id: string) => {
    setHistory(prev => prev.filter(item => item.id !== id));
  };

  const handleClearAllHistory = () => {
    setHistory([]);
  };

  const handleSelectHistoricalAssessment = (saved: SavedAssessment) => {
    const recalculated = calculateCardioPrediction(saved.inputs);
    setLatestResult(recalculated);
    setCurrentTab('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-teal-100 selection:text-teal-900">
      {/* Top Navigation */}
      <Header
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        hasAssessment={latestResult !== null}
        userEmail={userEmail}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        {currentTab === 'landing' && (
          <LandingHero
            onStartAssessment={() => {
              setCurrentTab('assessment');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onExploreModels={() => {
              setCurrentTab('transparency');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onExploreDictionary={() => {
              setCurrentTab('dictionary');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentTab === 'assessment' && (
          <AssessmentForm
            onSubmit={handleAssessmentSubmit}
            initialData={latestResult?.inputs}
          />
        )}

        {currentTab === 'results' && latestResult && (
          <PredictionView
            result={latestResult}
            onRetake={() => {
              setCurrentTab('assessment');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSaveToHistory={handleSaveToHistory}
            isSaved={history.some(h => h.id === latestResult.assessmentId)}
          />
        )}

        {currentTab === 'transparency' && (
          <ModelTransparency />
        )}

        {currentTab === 'dictionary' && (
          <DataDictionaryView />
        )}

        {currentTab === 'mlops' && (
          <MLOpsDashboard />
        )}

        {currentTab === 'history' && (
          <UserDashboard
            history={history}
            onSelectAssessment={handleSelectHistoricalAssessment}
            onDeleteAssessment={handleDeleteAssessment}
            onClearAllHistory={handleClearAllHistory}
            userEmail={userEmail}
          />
        )}
      </main>

      {/* Professional Healthcare Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white text-slate-600 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-teal-600" />
                <span className="font-bold text-slate-900 text-sm">CardioSense AI</span>
              </div>
              <p className="text-slate-500 max-w-xl">
                Public health surveillance and educational cardiovascular screening platform. Powered by CDC BRFSS 2021 machine learning models and SHAP local attribution.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-6 text-slate-600">
              <button
                onClick={() => setCurrentTab('transparency')}
                className="hover:text-slate-900 transition-colors"
              >
                Model Card & Validation
              </button>
              <button
                onClick={() => setCurrentTab('dictionary')}
                className="hover:text-slate-900 transition-colors"
              >
                Data Dictionary
              </button>
              <button
                onClick={() => setCurrentTab('mlops')}
                className="hover:text-slate-900 transition-colors"
              >
                MLOps & Drift
              </button>
              <a
                href="https://www.cdc.gov/brfss/annual_data/annual_2021.html"
                target="_blank"
                rel="noreferrer"
                className="hover:text-teal-700 transition-colors"
              >
                CDC BRFSS Source
              </a>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-[11px] text-slate-400">
            <div>
              CardioSense AI is strictly an educational tool. It does not replace medical advice, clinical judgment, or medical diagnosis.
            </div>
            <div>
              CDC BRFSS 2021 Stratified Sample (40,000 Records) · Model v1.4.2-calibrated-hgb
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
