/**
 * CardioSense AI - PDF Clinical Assessment Summary Generator
 */

import { jsPDF } from 'jspdf';
import { PredictionResult } from '../types/cardio';

export function exportAssessmentToPDF(result: PredictionResult): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const primaryNavy = '#0f172a';
  const tealAccent = '#0d9488';
  const textDark = '#1e293b';
  const textMuted = '#64748b';
  const margin = 20;
  let y = 20;

  // Header Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.setTextColor(primaryNavy);
  doc.text('CardioSense AI', margin, y);
  y += 7;

  // Subtitle
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(textMuted);
  doc.text('Educational Cardiovascular Risk Screening Report', margin, y);
  y += 4;
  doc.text(`Generated: ${new Date(result.timestamp).toLocaleString()} | Model: ${result.modelVersion}`, margin, y);
  y += 6;

  // Hairline Divider
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(margin, y, 190, y);
  y += 10;

  // Prominent Medical Disclaimer Box
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(margin, y, 170, 18, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor('#b91c1c'); // restrained red
  doc.text('CRITICAL NOTICE — NOT A MEDICAL DIAGNOSIS', margin + 4, y + 6);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(textDark);
  doc.text(
    'This educational report estimates likelihood based on survey patterns from the CDC BRFSS 2021 dataset.\nIt does NOT replace medical evaluation. For chest pain, shortness of breath, or fainting, call 911 immediately.',
    margin + 4,
    y + 11
  );
  y += 24;

  // Results Overview Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(margin, y, 170, 32, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryNavy);
  doc.text('Screening Summary & Estimated Likelihood', margin + 5, y + 8);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(textMuted);
  doc.text('Estimated Likelihood:', margin + 5, y + 17);
  doc.text('Screening Risk Tier:', margin + 65, y + 17);
  doc.text('95% Confidence Interval:', margin + 120, y + 17);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  const riskColor = result.riskCategory === 'High' ? '#dc2626' : result.riskCategory === 'Moderate' ? '#d97706' : '#0d9488';
  doc.setTextColor(riskColor);
  doc.text(`${result.probabilityPercent}%`, margin + 5, y + 25);
  doc.text(result.riskCategory.toUpperCase(), margin + 65, y + 25);

  doc.setFontSize(11);
  doc.setTextColor(textDark);
  doc.text(`[${result.confidenceInterval[0]}% - ${result.confidenceInterval[1]}%]`, margin + 120, y + 25);
  y += 38;

  // Key Factors (SHAP Explanations)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(primaryNavy);
  doc.text('Top Influencing Factors (SHAP Local Attribution)', margin, y);
  y += 6;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(textMuted);
  doc.text('Relative contribution compared to the CDC BRFSS baseline population prevalence (8.8%):', margin, y);
  y += 6;

  // Top 5 factors
  const topFactors = result.shapFactors.slice(0, 5);
  topFactors.forEach((factor, idx) => {
    const isIncrease = factor.direction === 'increases_risk';
    const tag = isIncrease ? '(+ Increases Risk)' : factor.direction === 'decreases_risk' ? '(- Lowers Risk)' : '(Neutral)';
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(textDark);
    doc.text(`${idx + 1}. ${factor.label}: ${factor.userValue}`, margin + 2, y);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(isIncrease ? '#b91c1c' : '#047857');
    doc.text(tag, margin + 120, y);

    y += 4.5;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(textMuted);
    doc.text(factor.clinicalContext, margin + 6, y, { maxWidth: 160 });
    y += 7;
  });

  y += 2;

  // Prevention Guidance
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(primaryNavy);
  doc.text('Personalized Evidence-Based Prevention Considerations', margin, y);
  y += 6;

  const topRecs = result.recommendations.slice(0, 3);
  topRecs.forEach((rec, idx) => {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(primaryNavy);
    doc.text(`${idx + 1}. ${rec.title}`, margin + 2, y);
    y += 4;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(textDark);
    doc.text(rec.description, margin + 6, y, { maxWidth: 160 });
    y += 4;

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7.5);
    doc.setTextColor(textMuted);
    doc.text(`Guideline source: ${rec.evidenceBase}`, margin + 6, y);
    y += 6;
  });

  // Footer Disclaimer
  doc.setDrawColor(226, 232, 240);
  doc.line(margin, 275, 190, 275);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(textMuted);
  doc.text(
    'CardioSense AI — Research & Educational Health Screening Platform · Dataset: CDC BRFSS 2021 (40,000 Sample) · Page 1 of 1',
    margin,
    280
  );

  // Trigger download
  doc.save(`CardioSense_Assessment_${result.assessmentId}.pdf`);
}
