/**
 * CardioSense AI - Type Definitions
 * Based on official CDC BRFSS 2021 Public Health Dataset
 */

export type AgeCategory =
  | 'Age 18-24'
  | 'Age 25-29'
  | 'Age 30-34'
  | 'Age 35-39'
  | 'Age 40-44'
  | 'Age 45-49'
  | 'Age 50-54'
  | 'Age 55-59'
  | 'Age 60-64'
  | 'Age 65-69'
  | 'Age 70-74'
  | 'Age 75-79'
  | 'Age 80 or older';

export type Sex = 'Male' | 'Female';

export type SmokingStatus =
  | 'Never smoked'
  | 'Former smoker'
  | 'Current smoker - some days'
  | 'Current smoker - everyday';

export type AlcoholDrinking = 'No' | 'Yes'; // Heavy drinker (>14 drinks/week for men, >7 drinks/week for women)

export type PhysicalActivity = 'Yes' | 'No'; // Any physical activity in past 30 days other than regular job

export type DiabetesStatus =
  | 'No'
  | 'Yes'
  | 'Borderline / Pre-diabetes'
  | 'Gestational only';

export type GeneralHealth =
  | 'Excellent'
  | 'Very good'
  | 'Good'
  | 'Fair'
  | 'Poor';

export type YesNo = 'Yes' | 'No';

export interface AssessmentFormData {
  // Step 1: Personal Details
  ageCategory: AgeCategory;
  sex: Sex;
  heightFeet: number;
  heightInches: number;
  weightLbs: number;
  bmi: number;
  
  // Step 2: Lifestyle
  smokingStatus: SmokingStatus;
  alcoholDrinking: AlcoholDrinking;
  physicalActivity: PhysicalActivity;
  sleepHours: number;

  // Step 3: Medical Conditions
  highBloodPressure: YesNo;
  highCholesterol: YesNo;
  diabetes: DiabetesStatus;
  stroke: YesNo;

  // Step 4: Functional & General Health
  generalHealth: GeneralHealth;
  diffWalking: YesNo;

  // Research / Subgroup Fairness (optional review)
  raceEthnicity?: string;
  educationLevel?: string;

  // Acknowledgement
  disclaimerAccepted: boolean;
}

export type RiskCategory = 'Low' | 'Moderate' | 'High';

export interface ShapFactor {
  feature: string;
  label: string;
  userValue: string | number;
  shapValue: number; // Log-odds or probability contribution
  direction: 'increases_risk' | 'decreases_risk' | 'neutral';
  clinicalContext: string;
}

export interface PreventionRecommendation {
  category: string;
  title: string;
  description: string;
  evidenceBase: string;
  priority: 'high' | 'medium' | 'routine';
}

export interface PredictionResult {
  assessmentId: string;
  timestamp: string;
  modelVersion: string;
  probabilityPercent: number; // e.g. 18.4%
  riskCategory: RiskCategory;
  confidenceInterval: [number, number]; // e.g. [15.2, 21.6]
  baselinePopulationRisk: number; // CDC BRFSS 2021 weighted baseline: 8.8%
  shapFactors: ShapFactor[];
  recommendations: PreventionRecommendation[];
  urgentWarning: boolean;
  inputs: AssessmentFormData;
}

export interface SavedAssessment {
  id: string;
  userId: string;
  userName: string;
  timestamp: string;
  modelVersion: string;
  probabilityPercent: number;
  riskCategory: RiskCategory;
  inputs: AssessmentFormData;
  summaryHighlights: string[];
}

export interface ModelBenchmark {
  id: string;
  name: string;
  type: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  rocAuc: number;
  prAuc: number;
  brierScore: number;
  calibrationMethod: string;
  isSelectedChampion: boolean;
  notes: string;
}

export interface DriftMetric {
  feature: string;
  baselineMean: number;
  currentMean: number;
  psi: number; // Population Stability Index
  status: 'nominal' | 'moderate_drift' | 'critical_drift';
}
