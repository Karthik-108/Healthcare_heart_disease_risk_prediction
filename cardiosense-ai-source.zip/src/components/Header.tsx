/**
 * CardioSense AI - Top Navigation Bar
 * Conforms to Top Bar Contract: 3 zones, 1 line, zero-pill discipline
 */

import React from 'react';
import { Activity, ShieldCheck, Database, Sliders, History, FileText } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  hasAssessment: boolean;
  userEmail: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  hasAssessment,
  userEmail
}) => {
  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setCurrentTab('landing')}
              className="flex items-center gap-2 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 rounded"
            >
              <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white shadow-sm">
                <Activity className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-900 group-hover:text-teal-700 transition-colors whitespace-nowrap shrink-0">
                CardioSense AI
              </span>
            </button>
          </div>

          {/* Zone 2: Clean single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => setCurrentTab('assessment')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                currentTab === 'assessment' ? 'border-teal-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              Risk Assessment
            </button>

            {hasAssessment && (
              <button
                onClick={() => setCurrentTab('results')}
                className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                  currentTab === 'results' ? 'border-teal-600 text-slate-900 font-semibold' : 'border-transparent'
                }`}
              >
                Prediction Results
              </button>
            )}

            <button
              onClick={() => setCurrentTab('transparency')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                currentTab === 'transparency' ? 'border-teal-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              Model Performance
            </button>

            <button
              onClick={() => setCurrentTab('dictionary')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                currentTab === 'dictionary' ? 'border-teal-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              Data Dictionary
            </button>

            <button
              onClick={() => setCurrentTab('mlops')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                currentTab === 'mlops' ? 'border-teal-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              MLOps & Drift
            </button>

            <button
              onClick={() => setCurrentTab('history')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                currentTab === 'history' ? 'border-teal-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              Patient History
            </button>
          </nav>

          {/* Zone 3: Actions */}
          <div className="flex items-center gap-2.5 shrink-0">
            <a
              href="/cardiosense-ai-source.zip"
              download="cardiosense-ai-source.zip"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-xs cursor-pointer"
              title="Download complete project source code as a ZIP archive"
            >
              <FileText className="w-3.5 h-3.5 text-teal-700" />
              <span>Download ZIP</span>
            </a>

            <button
              onClick={() => setCurrentTab('assessment')}
              className="px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm cursor-pointer"
            >
              Start Screening
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Row */}
      <div className="md:hidden border-t border-slate-100 px-4 py-2 flex items-center justify-between overflow-x-auto text-xs font-medium text-slate-600 gap-4">
        <button
          onClick={() => setCurrentTab('assessment')}
          className={`whitespace-nowrap shrink-0 ${currentTab === 'assessment' ? 'text-teal-700 font-semibold' : ''}`}
        >
          Screening
        </button>
        {hasAssessment && (
          <button
            onClick={() => setCurrentTab('results')}
            className={`whitespace-nowrap shrink-0 ${currentTab === 'results' ? 'text-teal-700 font-semibold' : ''}`}
          >
            Results
          </button>
        )}
        <button
          onClick={() => setCurrentTab('transparency')}
          className={`whitespace-nowrap shrink-0 ${currentTab === 'transparency' ? 'text-teal-700 font-semibold' : ''}`}
        >
          Models
        </button>
        <button
          onClick={() => setCurrentTab('dictionary')}
          className={`whitespace-nowrap shrink-0 ${currentTab === 'dictionary' ? 'text-teal-700 font-semibold' : ''}`}
        >
          Dictionary
        </button>
        <button
          onClick={() => setCurrentTab('mlops')}
          className={`whitespace-nowrap shrink-0 ${currentTab === 'mlops' ? 'text-teal-700 font-semibold' : ''}`}
        >
          MLOps
        </button>
        <button
          onClick={() => setCurrentTab('history')}
          className={`whitespace-nowrap shrink-0 ${currentTab === 'history' ? 'text-teal-700 font-semibold' : ''}`}
        >
          History
        </button>
      </div>
    </header>
  );
};
