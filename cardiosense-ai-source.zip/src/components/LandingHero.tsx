/**
 * CardioSense AI - Landing Page Hero & Core Principles
 */

import React from 'react';
import { ArrowRight, ShieldCheck, HeartPulse, Sparkles, AlertCircle, FileCheck, Lock, Activity } from 'lucide-react';

interface LandingHeroProps {
  onStartAssessment: () => void;
  onExploreModels: () => void;
  onExploreDictionary: () => void;
}

export const LandingHero: React.FC<LandingHeroProps> = ({
  onStartAssessment,
  onExploreModels,
  onExploreDictionary
}) => {
  return (
    <div className="space-y-16 py-8">
      {/* Prominent Educational Screening & Safety Banner */}
      <div className="bg-amber-50/90 border border-amber-200/80 rounded-xl p-4 sm:p-5 text-amber-950">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-1 text-sm">
            <p className="font-semibold text-amber-900">
              Educational Screening Tool · Not a Medical Diagnostic System
            </p>
            <p className="text-amber-800 leading-relaxed">
              CardioSense AI is designed exclusively for public health education and personal risk awareness using population statistical models derived from the CDC BRFSS surveillance dataset. It does not provide medical diagnoses, treatment advice, or triage acute clinical emergencies.
              <span className="font-medium text-amber-950 block mt-1">
                For chest tightness, radiating pain, sudden shortness of breath, or fainting, contact emergency medical services (911 in the US) immediately.
              </span>
            </p>
          </div>
        </div>
      </div>

      {/* Hero Section Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-7 space-y-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider">
              <span>CDC BRFSS 2021 Public Health Machine Learning</span>
              <span aria-hidden="true">·</span>
              <span>40,000 Stratified Cohort</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900 leading-tight">
              Understand Your Heart Health Risk
            </h1>

            <p className="text-lg text-slate-600 leading-relaxed">
              Explore your statistical likelihood of belonging to a cohort reporting diagnosed coronary heart disease or prior myocardial infarction. Powered by calibrated machine learning and personalized SHAP feature explainability.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3.5 pt-2">
            <button
              onClick={onStartAssessment}
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 cursor-pointer"
            >
              <span>Start Assessment</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onExploreModels}
              className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-base font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-400 cursor-pointer"
            >
              <span>Explore Model Performance</span>
            </button>

            <a
              href="/cardiosense-ai-source.zip"
              download="cardiosense-ai-source.zip"
              className="inline-flex items-center justify-center gap-2 px-4 py-3.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors cursor-pointer"
              title="Download entire CardioSense AI codebase as a .ZIP archive"
            >
              <FileCheck className="w-4 h-4 text-teal-700" />
              <span>Download Source (.ZIP)</span>
            </a>
          </div>

          {/* Privacy & Methodology Guarantee */}
          <div className="pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-500">
            <div className="flex items-start gap-2">
              <Lock className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-700 block">Client-Controlled Privacy</strong>
                Responses are processed directly in your browser session. No tracking cookies or commercial data sales.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <FileCheck className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-700 block">Surveillance-Grounded Math</strong>
                Calibrated against CDC BRFSS 2021 weighted surveillance records; calibrated using isotonic regression.
              </div>
            </div>
          </div>
        </div>

        {/* Hero Visual Stage */}
        <div className="lg:col-span-5">
          <div className="relative rounded-2xl overflow-hidden border border-slate-200/90 shadow-lg bg-slate-900 group">
            <img
              src="/src/assets/images/cardio_hero_visual_1794035821670.jpg"
              alt="Clinical cardiovascular analytics display with hemodynamic monitors and heart hologram"
              referrerPolicy="no-referrer"
              className="w-full h-[400px] object-cover group-hover:scale-102 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent flex flex-col justify-end p-6 text-white">
              <div className="flex items-center gap-2 text-xs font-mono text-teal-300">
                <span>MODEL PIPELINE: ENSEMBLE HIST-GB</span>
                <span aria-hidden="true">·</span>
                <span>PR-AUC 0.452</span>
              </div>
              <p className="text-sm font-medium mt-1 text-slate-100">
                Surveillance-grade risk modeling calibrated for non-clinical educational self-screening.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Proof Metrics Strip */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 divide-y sm:divide-y-0 sm:divide-x divide-slate-100">
          <div className="px-3 py-2 space-y-1">
            <div className="text-xs uppercase font-medium text-slate-400">Sample Population</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-slate-900">40,000</div>
            <div className="text-xs text-slate-500">CDC BRFSS 2021 valid records</div>
          </div>

          <div className="px-3 py-2 space-y-1">
            <div className="text-xs uppercase font-medium text-slate-400">Surveillance Target</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-slate-900">_MICHD</div>
            <div className="text-xs text-slate-500">CHD or Myocardial Infarction</div>
          </div>

          <div className="px-3 py-2 space-y-1">
            <div className="text-xs uppercase font-medium text-slate-400">Baseline Prevalence</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-slate-900">8.81 %</div>
            <div className="text-xs text-slate-500">Weighted US survey baseline</div>
          </div>

          <div className="px-3 py-2 space-y-1">
            <div className="text-xs uppercase font-medium text-slate-400">Explainability</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-teal-700">SHAP</div>
            <div className="text-xs text-slate-500">Local feature attributions</div>
          </div>
        </div>
      </section>

      {/* Core Workflow Pillars */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">
            How CardioSense AI Works
          </h2>
          <p className="text-sm text-slate-600">
            A transparent four-phase process from survey inputs to individualized SHAP factor decomposition.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center text-teal-700 font-bold text-sm">
              01
            </div>
            <h3 className="text-lg font-semibold text-slate-900">Multi-Domain Screening Input</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Answer 13 validated non-leaking lifestyle, biometric, and medical history questions from the CDC Behavioral Risk Factor Surveillance System.
            </p>
            <div className="text-xs text-teal-700 pt-2 font-medium">
              No invasive lab tests required · 3-minute completion
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-slate-800 font-bold text-sm">
              02
            </div>
            <h3 className="text-lg font-semibold text-slate-900">Calibrated Ensemble Scoring</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Your inputs are evaluated against our champion HistGradientBoosting model, calibrated with Platt scaling to output realistic probabilities rather than overconfident classifications.
            </p>
            <div className="text-xs text-slate-600 pt-2 font-medium">
              Evaluated on 6,000 holdout records · Brier score 0.059
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center text-teal-700 font-bold text-sm">
              03
            </div>
            <h3 className="text-lg font-semibold text-slate-900">SHAP Transparency & Action</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              See exactly which factors increased or decreased your score relative to population baseline, paired with guidelines-backed prevention topics to discuss with your doctor.
            </p>
            <div className="text-xs text-teal-700 pt-2 font-medium">
              AHA/ACC evidence tiers · Downloadable PDF report
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
