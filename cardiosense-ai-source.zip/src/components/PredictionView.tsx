/**
 * CardioSense AI - Prediction Results & Explainability View
 */

import React, { useState } from 'react';
import { PredictionResult, SavedAssessment } from '../types/cardio';
import { RiskGauge } from './RiskGauge';
import { exportAssessmentToPDF } from '../utils/pdfGenerator';
import {
  AlertTriangle,
  Download,
  BookmarkCheck,
  RotateCcw,
  CheckCircle,
  HelpCircle,
  ArrowUpRight,
  ArrowDownRight,
  Heart,
  ShieldAlert,
  Info
} from 'lucide-react';

interface PredictionViewProps {
  result: PredictionResult;
  onRetake: () => void;
  onSaveToHistory: (assessment: SavedAssessment) => void;
  isSaved?: boolean;
}

export const PredictionView: React.FC<PredictionViewProps> = ({
  result,
  onRetake,
  onSaveToHistory,
  isSaved = false
}) => {
  const [savedSuccess, setSavedSuccess] = useState<boolean>(isSaved);

  const handleSave = () => {
    const highlights = result.shapFactors.slice(0, 3).map(f => `${f.label}: ${f.userValue}`);
    const savedObj: SavedAssessment = {
      id: result.assessmentId,
      userId: 'user_active_01',
      userName: 'Active Patient Session',
      timestamp: result.timestamp,
      modelVersion: result.modelVersion,
      probabilityPercent: result.probabilityPercent,
      riskCategory: result.riskCategory,
      inputs: result.inputs,
      summaryHighlights: highlights
    };
    onSaveToHistory(savedObj);
    setSavedSuccess(true);
  };

  const handleDownloadPDF = () => {
    exportAssessmentToPDF(result);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 py-6">
      {/* Acute Emergency Safety Alert Banner (if High Risk or Severe Symptoms) */}
      {result.urgentWarning && (
        <div className="bg-rose-50 border-2 border-rose-300 rounded-xl p-5 text-rose-950 shadow-sm animate-pulse">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-6 h-6 text-rose-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="font-bold text-base text-rose-900">
                Critical Safety Guidance — Seek Immediate Medical Attention for Acute Symptoms
              </h3>
              <p className="text-sm text-rose-800 leading-relaxed">
                For chest pain, tightness or pressure, trouble breathing, unexplained fainting, or sudden numbness, contact local emergency medical services (such as 911) immediately. Do not rely on web assessments during an acute cardiac episode.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Primary Result Card */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider">
              <span>CDC BRFSS Surveillance Estimation</span>
              <span aria-hidden="true">·</span>
              <span>Model {result.modelVersion}</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 mt-1">
              Screening Assessment Findings
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Estimated statistical likelihood based on multivariable epidemiological patterns in survey data.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={handleDownloadPDF}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-600" />
              <span>Download PDF Summary</span>
            </button>

            <button
              onClick={handleSave}
              disabled={savedSuccess}
              className={`inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                savedSuccess
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 cursor-default'
                  : 'bg-teal-600 text-white hover:bg-teal-700'
              }`}
            >
              <BookmarkCheck className="w-4 h-4" />
              <span>{savedSuccess ? 'Saved to Profile' : 'Save to History'}</span>
            </button>
          </div>
        </div>

        {/* Top Grid: Gauge & Clinical Interpretation */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5">
            <RiskGauge
              probabilityPercent={result.probabilityPercent}
              riskCategory={result.riskCategory}
              confidenceInterval={result.confidenceInterval}
            />
          </div>

          <div className="lg:col-span-7 space-y-4">
            <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Surveillance Cohort Comparison
                </span>
                <span className="text-xs font-mono text-slate-500">
                  Baseline CDC Prevalence: 8.81%
                </span>
              </div>

              <p className="text-sm text-slate-700 leading-relaxed">
                This screening model estimates an{' '}
                <strong className="text-slate-900 font-semibold">
                  {result.riskCategory === 'Low'
                    ? 'expected low likelihood'
                    : result.riskCategory === 'Moderate'
                    ? 'elevated moderate likelihood'
                    : 'elevated high likelihood'}
                </strong>{' '}
                ({result.probabilityPercent}% estimated probability, 95% CI: [{result.confidenceInterval[0]}% - {result.confidenceInterval[1]}%]) that your profile shares characteristics with adults reporting diagnosed coronary heart disease or prior myocardial infarction in the CDC BRFSS surveillance dataset.
              </p>

              <div className="text-xs text-slate-500 bg-white p-3 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center gap-1.5 font-medium text-slate-700">
                  <Info className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                  <span>Important Non-Diagnostic Boundary</span>
                </div>
                <p>
                  This model does not measure coronary calcium, arterial stenoses, or cardiac troponin. An elevated score indicates statistical similarity to a survey population, not an individual diagnosis.
                </p>
              </div>
            </div>

            {/* Quick Summary of Inputs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="bg-white border border-slate-200 p-2.5 rounded-lg">
                <span className="text-slate-400 block">Age Cohort</span>
                <span className="font-semibold text-slate-800">{result.inputs.ageCategory}</span>
              </div>
              <div className="bg-white border border-slate-200 p-2.5 rounded-lg">
                <span className="text-slate-400 block">BMI & Category</span>
                <span className="font-semibold text-slate-800">{result.inputs.bmi} kg/m²</span>
              </div>
              <div className="bg-white border border-slate-200 p-2.5 rounded-lg">
                <span className="text-slate-400 block">Blood Pressure</span>
                <span className="font-semibold text-slate-800">
                  {result.inputs.highBloodPressure === 'Yes' ? 'Elevated' : 'Normal'}
                </span>
              </div>
              <div className="bg-white border border-slate-200 p-2.5 rounded-lg">
                <span className="text-slate-400 block">Tobacco</span>
                <span className="font-semibold text-slate-800 truncate block">{result.inputs.smokingStatus}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SHAP Factor Decomposition (Explainability) */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div>
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold tracking-tight text-slate-900">
              Why this score? SHAP Factor Breakdown
            </h3>
            <span className="text-xs font-mono text-slate-400">TreeExplainer Attribution</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            SHAP (SHapley Additive exPlanations) isolates the exact mathematical influence of each entered answer compared to the CDC national baseline.
          </p>
        </div>

        <div className="space-y-3">
          {result.shapFactors.slice(0, 6).map((factor, index) => {
            const isIncrease = factor.direction === 'increases_risk';
            const isDecrease = factor.direction === 'decreases_risk';
            const barWidthPercent = Math.min(Math.abs(factor.shapValue) * 60, 100);

            return (
              <div
                key={factor.feature}
                className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-slate-50 transition-colors space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold font-mono text-slate-400">0{index + 1}</span>
                    <strong className="text-sm font-semibold text-slate-900">{factor.label}</strong>
                    <span className="text-xs text-slate-500">({String(factor.userValue)})</span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs font-mono font-semibold">
                    {isIncrease ? (
                      <span className="text-rose-700 flex items-center gap-0.5">
                        <ArrowUpRight className="w-3.5 h-3.5" />
                        +{factor.shapValue}
                      </span>
                    ) : isDecrease ? (
                      <span className="text-emerald-700 flex items-center gap-0.5">
                        <ArrowDownRight className="w-3.5 h-3.5" />
                        {factor.shapValue}
                      </span>
                    ) : (
                      <span className="text-slate-500">±0.00</span>
                    )}
                  </div>
                </div>

                {/* Contribution bar */}
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden flex">
                  {isDecrease ? (
                    <div
                      className="bg-emerald-600 h-full ml-auto rounded-full"
                      style={{ width: `${barWidthPercent}%` }}
                    />
                  ) : (
                    <div
                      className="bg-rose-600 h-full mr-auto rounded-full"
                      style={{ width: `${barWidthPercent}%` }}
                    />
                  )}
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {factor.clinicalContext}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Tailored Prevention Guidance */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div>
          <h3 className="text-lg font-bold tracking-tight text-slate-900">
            Guideline-Based Prevention Strategies
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Evidence-based lifestyle actions mapped directly to your modifiable cardiovascular drivers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {result.recommendations.map(rec => (
            <div
              key={rec.title}
              className="p-5 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-colors space-y-2 flex flex-col justify-between"
            >
              <div className="space-y-1.5">
                <div className="text-xs font-semibold uppercase tracking-wider text-teal-700">
                  {rec.category}
                </div>
                <h4 className="text-sm font-bold text-slate-900">{rec.title}</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {rec.description}
                </p>
              </div>

              <div className="pt-2 text-[11px] text-slate-400 border-t border-slate-100 flex items-center justify-between">
                <span>{rec.evidenceBase}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-200">
          <button
            onClick={onRetake}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Retake Assessment</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export Official PDF Report</span>
          </button>
        </div>
      </section>
    </div>
  );
};
