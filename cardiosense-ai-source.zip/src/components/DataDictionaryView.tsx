/**
 * CardioSense AI - Interactive Data Dictionary Explorer
 */

import React, { useState } from 'react';
import { CDC_BRFSS_DATA_DICTIONARY, VariableMeta } from '../data/dataDictionary';
import { Search, Filter, BookOpen, AlertCircle, Info, ShieldCheck } from 'lucide-react';

export const DataDictionaryView: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = ['all', 'Target', 'Demographic', 'Lifestyle', 'Clinical', 'General Health'];

  const filtered = CDC_BRFSS_DATA_DICTIONARY.filter(item => {
    const matchesSearch =
      item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.clinicalRationale.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory =
      selectedCategory === 'all' || item.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-6xl mx-auto space-y-8 py-6">
      {/* Title */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider">
          <span>CDC BRFSS 2021 Reference Codebook</span>
          <span aria-hidden="true">·</span>
          <span>Public Health Surveillance Specifications</span>
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
          Variables & Clinical Data Dictionary
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
          Exhaustive specifications of every variable used in CardioSense AI, including CDC question wording, response codes, non-leaking input verification, and epidemiological rationale.
        </p>
      </div>

      {/* Target Leakage Prevention Guarantee */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
        <div className="space-y-1 text-xs text-slate-600">
          <strong className="text-slate-900 block text-sm">Target Leakage Prevention Architecture</strong>
          <p>
            The surveillance target label <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono text-slate-800">_MICHD</code> is strictly isolated from model training input features. Variables that would directly leak the outcome (e.g. coronary angiography findings, post-infarction nitrate prescriptions, or immediate emergency room triage data) are excluded to ensure valid prospective screening capability.
          </p>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search code or clinical rationale..."
            className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
          />
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto w-full sm:w-auto">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat === 'all' ? 'All Variables (14)' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Dictionary Cards */}
      <div className="space-y-4">
        {filtered.map(item => (
          <div
            key={item.code}
            className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4 hover:border-slate-300 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs font-bold bg-slate-100 text-slate-800 px-2 py-1 rounded border border-slate-200">
                  {item.code}
                </span>
                <h3 className="text-base font-bold text-slate-900">{item.name}</h3>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500">{item.category}</span>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className={`font-semibold ${
                  item.leakageStatus === 'Target Label'
                    ? 'text-rose-700'
                    : 'text-teal-700'
                }`}>
                  {item.leakageStatus}
                </span>
              </div>
            </div>

            {/* Question Text */}
            <div className="space-y-1">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                CDC BRFSS Survey Question
              </span>
              <p className="text-xs sm:text-sm text-slate-800 italic bg-slate-50 p-3 rounded-lg border border-slate-100">
                "{item.questionText}"
              </p>
            </div>

            {/* Clinical Rationale & Response Codes */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
              <div className="md:col-span-7 space-y-1">
                <span className="font-semibold text-slate-700 block">Clinical & Pathophysiological Rationale:</span>
                <p className="text-slate-600 leading-relaxed">{item.clinicalRationale}</p>
              </div>

              <div className="md:col-span-5 space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-100">
                <span className="font-semibold text-slate-700 block">Response Code Schema:</span>
                <ul className="space-y-1 text-slate-600 text-[11px]">
                  {item.responseOptions.map(opt => (
                    <li key={opt.code} className="flex items-start gap-1.5">
                      <strong className="font-mono text-slate-800 shrink-0">[{opt.code}]</strong>
                      <span>{opt.label} — {opt.meaning}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
