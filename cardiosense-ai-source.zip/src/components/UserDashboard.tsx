/**
 * CardioSense AI - User Dashboard & Longitudinal Assessment History
 */

import React, { useState } from 'react';
import { SavedAssessment } from '../types/cardio';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from 'recharts';
import {
  History,
  Trash2,
  Calendar,
  Eye,
  TrendingUp,
  User,
  Shield,
  AlertCircle,
  FileText
} from 'lucide-react';

interface UserDashboardProps {
  history: SavedAssessment[];
  onSelectAssessment: (assessment: SavedAssessment) => void;
  onDeleteAssessment: (id: string) => void;
  onClearAllHistory: () => void;
  userEmail: string;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  history,
  onSelectAssessment,
  onDeleteAssessment,
  onClearAllHistory,
  userEmail
}) => {
  const [confirmClearModal, setConfirmClearModal] = useState<boolean>(false);

  // Prepare longitudinal trend data
  const trendData = [...history]
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map(item => ({
      date: new Date(item.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      probability: item.probabilityPercent,
      category: item.riskCategory,
      id: item.id
    }));

  return (
    <div className="max-w-5xl mx-auto space-y-8 py-6">
      {/* Profile & Privacy Overview */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700 font-bold">
            <User className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">Patient Screening Profile</h2>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span>Account: {userEmail}</span>
              <span aria-hidden="true">·</span>
              <span>Encrypted Client Storage</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {history.length > 0 && (
            <button
              onClick={() => setConfirmClearModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-rose-700 hover:text-rose-900 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete All My History</span>
            </button>
          )}
        </div>
      </div>

      {/* Confirmation Modal for Delete All */}
      {confirmClearModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-200 p-6 max-w-md w-full shadow-xl space-y-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-6 h-6 text-rose-600 shrink-0" />
              <div>
                <h3 className="font-bold text-base text-slate-900">Delete Assessment History?</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  This action permanently erases all saved assessment records from your device session. This cannot be undone.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                onClick={() => setConfirmClearModal(false)}
                className="px-4 py-2 text-xs font-medium text-slate-700 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onClearAllHistory();
                  setConfirmClearModal(false);
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs"
              >
                Yes, Delete My Data
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Longitudinal Risk Trend Chart (Shown only when multiple assessments exist) */}
      {trendData.length >= 2 ? (
        <section className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-teal-600" />
              <h3 className="text-base font-bold text-slate-900">
                Longitudinal Screening Risk Trajectory
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {trendData.length} Assessments Tracked
            </span>
          </div>

          <p className="text-xs text-slate-500">
            Observes changes in estimated risk probability across repeated screening sessions.
          </p>

          <div className="h-60 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} unit="%" domain={[0, 60]} />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Estimated Likelihood']}
                />
                <Line
                  type="monotone"
                  dataKey="probability"
                  stroke="#0d9488"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#0d9488' }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>
      ) : (
        history.length === 1 && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs text-slate-500">
            <strong>Longitudinal Note:</strong> Complete additional screening assessments over time to generate a visual trajectory curve.
          </div>
        )
      )}

      {/* History Table */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-6 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">Prior Assessment Records</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Strictly segregated to your profile session. Never exposed across accounts.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {history.length} Record{history.length === 1 ? '' : 's'}
          </span>
        </div>

        {history.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <FileText className="w-10 h-10 text-slate-300 mx-auto" />
            <div className="text-sm font-semibold text-slate-700">No Assessments Saved Yet</div>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Take the heart health risk assessment and choose "Save to History" on the results page to track your screening trajectory.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-3">Screening Category</th>
                  <th className="py-3 px-3">Estimated Probability</th>
                  <th className="py-3 px-3">Model Serving</th>
                  <th className="py-3 px-4">Key Risk Drivers</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono tabular-nums text-slate-800">
                {history.map(item => {
                  const riskColor =
                    item.riskCategory === 'High'
                      ? 'text-rose-700'
                      : item.riskCategory === 'Moderate'
                      ? 'text-amber-700'
                      : 'text-teal-700';

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-sans text-slate-700">
                        {new Date(item.timestamp).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </td>
                      <td className={`py-3 px-3 font-sans font-semibold ${riskColor}`}>
                        {item.riskCategory}
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-900">
                        {item.probabilityPercent}%
                      </td>
                      <td className="py-3 px-3 text-slate-500 text-[11px]">
                        {item.modelVersion}
                      </td>
                      <td className="py-3 px-4 font-sans text-slate-600 text-[11px] max-w-xs truncate">
                        {item.summaryHighlights?.join(' · ') || 'Complete Profile'}
                      </td>
                      <td className="py-3 px-4 text-right space-x-2 font-sans">
                        <button
                          onClick={() => onSelectAssessment(item)}
                          className="inline-flex items-center gap-1 text-teal-700 hover:text-teal-900 font-medium cursor-pointer"
                          title="View Full Results"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View</span>
                        </button>
                        <button
                          onClick={() => onDeleteAssessment(item.id)}
                          className="inline-flex items-center gap-1 text-slate-400 hover:text-rose-600 ml-2 cursor-pointer"
                          title="Delete Record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
