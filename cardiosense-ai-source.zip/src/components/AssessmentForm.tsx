/**
 * CardioSense AI - Multi-Step Heart Risk Assessment Form
 */

import React, { useState, useEffect } from 'react';
import {
  AssessmentFormData,
  AgeCategory,
  Sex,
  SmokingStatus,
  AlcoholDrinking,
  PhysicalActivity,
  DiabetesStatus,
  GeneralHealth,
  YesNo
} from '../types/cardio';
import { computeBMICategory } from '../services/cardioModelEngine';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Info,
  RotateCcw,
  Sparkles,
  Save
} from 'lucide-react';

interface AssessmentFormProps {
  onSubmit: (data: AssessmentFormData) => void;
  initialData?: AssessmentFormData | null;
}

const AGE_OPTIONS: AgeCategory[] = [
  'Age 18-24',
  'Age 25-29',
  'Age 30-34',
  'Age 35-39',
  'Age 40-44',
  'Age 45-49',
  'Age 50-54',
  'Age 55-59',
  'Age 60-64',
  'Age 65-69',
  'Age 70-74',
  'Age 75-79',
  'Age 80 or older'
];

const DEFAULT_FORM_DATA: AssessmentFormData = {
  ageCategory: 'Age 50-54',
  sex: 'Male',
  heightFeet: 5,
  heightInches: 10,
  weightLbs: 175,
  bmi: 25.1,
  smokingStatus: 'Never smoked',
  alcoholDrinking: 'No',
  physicalActivity: 'Yes',
  sleepHours: 7,
  highBloodPressure: 'No',
  highCholesterol: 'No',
  diabetes: 'No',
  stroke: 'No',
  generalHealth: 'Very good',
  diffWalking: 'No',
  disclaimerAccepted: false
};

const DRAFT_KEY = 'cardiosense_assessment_draft_v1';

export const AssessmentForm: React.FC<AssessmentFormProps> = ({ onSubmit, initialData }) => {
  const [step, setStep] = useState<number>(1);
  const [formData, setFormData] = useState<AssessmentFormData>(() => {
    if (initialData) return initialData;
    const saved = localStorage.getItem(DRAFT_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return DEFAULT_FORM_DATA;
      }
    }
    return DEFAULT_FORM_DATA;
  });

  const [draftSavedAlert, setDraftSavedAlert] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Recalculate BMI whenever height or weight changes
  useEffect(() => {
    const totalInches = formData.heightFeet * 12 + formData.heightInches;
    if (totalInches > 0 && formData.weightLbs > 0) {
      const calculatedBmi = Number(((formData.weightLbs / (totalInches * totalInches)) * 703).toFixed(1));
      setFormData(prev => ({ ...prev, bmi: calculatedBmi }));
    }
  }, [formData.heightFeet, formData.heightInches, formData.weightLbs]);

  // Save draft locally
  useEffect(() => {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(formData));
  }, [formData]);

  const handleSaveDraft = () => {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(formData));
    setDraftSavedAlert(true);
    setTimeout(() => setDraftSavedAlert(false), 2500);
  };

  const handleReset = () => {
    setFormData(DEFAULT_FORM_DATA);
    setStep(1);
    localStorage.removeItem(DRAFT_KEY);
  };

  // Demo presets
  const loadPreset = (type: 'low' | 'moderate' | 'high') => {
    if (type === 'low') {
      setFormData({
        ageCategory: 'Age 30-34',
        sex: 'Female',
        heightFeet: 5,
        heightInches: 6,
        weightLbs: 135,
        bmi: 21.8,
        smokingStatus: 'Never smoked',
        alcoholDrinking: 'No',
        physicalActivity: 'Yes',
        sleepHours: 8,
        highBloodPressure: 'No',
        highCholesterol: 'No',
        diabetes: 'No',
        stroke: 'No',
        generalHealth: 'Excellent',
        diffWalking: 'No',
        disclaimerAccepted: true
      });
    } else if (type === 'moderate') {
      setFormData({
        ageCategory: 'Age 55-59',
        sex: 'Male',
        heightFeet: 5,
        heightInches: 11,
        weightLbs: 205,
        bmi: 28.6,
        smokingStatus: 'Former smoker',
        alcoholDrinking: 'No',
        physicalActivity: 'Yes',
        sleepHours: 6,
        highBloodPressure: 'Yes',
        highCholesterol: 'No',
        diabetes: 'Borderline / Pre-diabetes',
        stroke: 'No',
        generalHealth: 'Good',
        diffWalking: 'No',
        disclaimerAccepted: true
      });
    } else {
      setFormData({
        ageCategory: 'Age 65-69',
        sex: 'Male',
        heightFeet: 5,
        heightInches: 9,
        weightLbs: 220,
        bmi: 32.5,
        smokingStatus: 'Current smoker - everyday',
        alcoholDrinking: 'Yes',
        physicalActivity: 'No',
        sleepHours: 5,
        highBloodPressure: 'Yes',
        highCholesterol: 'Yes',
        diabetes: 'Yes',
        stroke: 'No',
        generalHealth: 'Poor',
        diffWalking: 'Yes',
        disclaimerAccepted: true
      });
    }
    setValidationError(null);
  };

  const validateStep = (currentStep: number): boolean => {
    setValidationError(null);

    if (currentStep === 1) {
      if (formData.heightFeet < 3 || formData.heightFeet > 7) {
        setValidationError('Please enter a valid height between 3 and 7 feet.');
        return false;
      }
      if (formData.weightLbs < 60 || formData.weightLbs > 500) {
        setValidationError('Please enter a weight between 60 and 500 lbs.');
        return false;
      }
      if (formData.bmi < 12 || formData.bmi > 75) {
        setValidationError('Calculated BMI is outside realistic biological bounds (12-75 kg/m²).');
        return false;
      }
    }

    if (currentStep === 2) {
      if (formData.sleepHours < 1 || formData.sleepHours > 24) {
        setValidationError('Sleep duration must be between 1 and 24 hours per day.');
        return false;
      }
    }

    if (currentStep === 4) {
      if (!formData.disclaimerAccepted) {
        setValidationError('You must acknowledge that this is an educational screening and not medical advice.');
        return false;
      }
    }

    return true;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(prev => Math.min(prev + 1, 4));
    }
  };

  const handleBack = () => {
    setValidationError(null);
    setStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateStep(4)) {
      onSubmit(formData);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 py-6">
      {/* Header and Preset Shortcuts */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">
            Cardiovascular Risk Assessment
          </h2>
          <p className="text-sm text-slate-500">
            Estimated 3-minute self-screening based on CDC BRFSS 2021 variables.
          </p>
        </div>

        {/* Quick Demo Pre-fill for Testing */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-slate-500">Load sample:</span>
          <button
            type="button"
            onClick={() => loadPreset('low')}
            className="px-2.5 py-1 text-xs font-medium rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors"
          >
            Low
          </button>
          <button
            type="button"
            onClick={() => loadPreset('moderate')}
            className="px-2.5 py-1 text-xs font-medium rounded bg-amber-50 text-amber-700 hover:bg-amber-100 transition-colors"
          >
            Moderate
          </button>
          <button
            type="button"
            onClick={() => loadPreset('high')}
            className="px-2.5 py-1 text-xs font-medium rounded bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors"
          >
            High
          </button>
        </div>
      </div>

      {/* Progress Bar & Steps */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-medium text-slate-500">
          <span>Step {step} of 4: {step === 1 ? 'Personal Details' : step === 2 ? 'Lifestyle & Habits' : step === 3 ? 'Medical Conditions' : 'General Health & Consent'}</span>
          <span>{Math.round((step / 4) * 100)}% Completed</span>
        </div>
        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
          <div
            className="bg-teal-600 h-full transition-all duration-300"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>
      </div>

      {/* Draft Notification */}
      {draftSavedAlert && (
        <div className="bg-teal-50 border border-teal-200 text-teal-800 text-xs px-4 py-2.5 rounded-lg flex items-center justify-between">
          <span>Draft progress successfully saved locally to your device.</span>
          <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
        </div>
      )}

      {/* Validation Error Banner */}
      {validationError && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 text-sm p-4 rounded-lg flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div>
            <strong className="block font-semibold">Action Required</strong>
            <span>{validationError}</span>
          </div>
        </div>
      )}

      {/* Form Content Stage */}
      <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        {/* STEP 1: Personal Details */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-lg font-semibold text-slate-900">Personal & Biometric Profile</h3>
              <p className="text-xs text-slate-500">Baseline demographic and body mass index variables from CDC BRFSS.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Age Category */}
              <div className="space-y-1.5">
                <label className="block text-sm font-medium text-slate-700">
                  Age Group <span className="text-rose-500">*</span>
                </label>
                <select
                  value={formData.ageCategory}
                  onChange={e => setFormData({ ...formData, ageCategory: e.target.value as AgeCategory })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
                >
                  {AGE_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
                <span className="text-xs text-slate-400">CDC variable: _AGEG5YR</span>
              </div>

              {/* Sex */}
              <div className="space-y-1.5">
                <label className="block text-sm font-medium text-slate-700">
                  Biological Sex <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3 pt-1">
                  {(['Male', 'Female'] as Sex[]).map(s => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setFormData({ ...formData, sex: s })}
                      className={`py-2 px-3 text-sm font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                        formData.sex === s
                          ? 'bg-teal-50 border-teal-600 text-teal-900'
                          : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <span className="text-xs text-slate-400">CDC variable: SEXVAR</span>
              </div>
            </div>

            {/* Height and Weight to Calculate BMI */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-semibold text-slate-800">
                  Height & Weight (Calculated BMI)
                </label>
                <span className="text-xs font-mono text-slate-500">CDC variable: _BMI5</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Height (Feet)</label>
                  <input
                    type="number"
                    min="3"
                    max="7"
                    value={formData.heightFeet}
                    onChange={e => setFormData({ ...formData, heightFeet: Number(e.target.value) })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Height (Inches)</label>
                  <input
                    type="number"
                    min="0"
                    max="11"
                    value={formData.heightInches}
                    onChange={e => setFormData({ ...formData, heightInches: Number(e.target.value) })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Weight (Pounds / lbs)</label>
                  <input
                    type="number"
                    min="60"
                    max="500"
                    value={formData.weightLbs}
                    onChange={e => setFormData({ ...formData, weightLbs: Number(e.target.value) })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>
              </div>

              {/* BMI Real-time Display */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-200">
                <span className="text-xs text-slate-600">Calculated Body Mass Index:</span>
                <div className="text-right">
                  <span className="text-base font-bold font-mono tabular-nums text-slate-900 mr-2">
                    {formData.bmi} kg/m²
                  </span>
                  <span className="text-xs font-medium text-slate-500">
                    ({computeBMICategory(formData.bmi)})
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Lifestyle & Habits */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-lg font-semibold text-slate-900">Lifestyle & Modifiable Behaviors</h3>
              <p className="text-xs text-slate-500">Tobacco use, exercise, sleep hygiene, and alcohol intake.</p>
            </div>

            {/* Smoking Status */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Tobacco Smoking Frequency <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {([
                  'Never smoked',
                  'Former smoker',
                  'Current smoker - some days',
                  'Current smoker - everyday'
                ] as SmokingStatus[]).map(status => (
                  <button
                    key={status}
                    type="button"
                    onClick={() => setFormData({ ...formData, smokingStatus: status })}
                    className={`py-2.5 px-3.5 text-xs sm:text-sm font-medium rounded-lg border text-left transition-colors cursor-pointer ${
                      formData.smokingStatus === status
                        ? 'bg-teal-50 border-teal-600 text-teal-900 font-semibold'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {status}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: SMOKDAY2 (Lifetime threshold: 100 cigarettes)</span>
            </div>

            {/* Exercise in past 30 days */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Leisure-Time Physical Activity <span className="text-rose-500">*</span>
              </label>
              <p className="text-xs text-slate-500">
                During the past 30 days, other than your regular job, did you participate in any physical exercises (walking, running, sports, gardening)?
              </p>
              <div className="grid grid-cols-2 gap-3 pt-1">
                {(['Yes', 'No'] as YesNo[]).map(opt => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setFormData({ ...formData, physicalActivity: opt })}
                    className={`py-2 px-3 text-sm font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.physicalActivity === opt
                        ? 'bg-teal-50 border-teal-600 text-teal-900'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt === 'Yes' ? 'Yes (Participated in Activity)' : 'No (Inactivity / Sedentary)'}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: _TOTINDA</span>
            </div>

            {/* Sleep Duration */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-sm font-medium text-slate-700">
                  Average Sleep Duration per 24 Hours <span className="text-rose-500">*</span>
                </label>
                <span className="text-sm font-bold font-mono text-teal-700">
                  {formData.sleepHours} Hours / Day
                </span>
              </div>
              <input
                type="range"
                min="3"
                max="14"
                step="1"
                value={formData.sleepHours}
                onChange={e => setFormData({ ...formData, sleepHours: Number(e.target.value) })}
                className="w-full accent-teal-600 cursor-pointer"
              />
              <div className="flex justify-between text-xs text-slate-400">
                <span>3 hrs</span>
                <span>7 - 8 hrs (Recommended)</span>
                <span>14 hrs</span>
              </div>
              <span className="text-xs text-slate-400 block">CDC variable: SLEPTIM1 (U-shaped cardiovascular risk curve)</span>
            </div>

            {/* Heavy Alcohol Drinking */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Heavy Alcohol Consumption <span className="text-rose-500">*</span>
              </label>
              <p className="text-xs text-slate-500">
                Defined by CDC as &gt;14 drinks per week for adult men, or &gt;7 drinks per week for adult women.
              </p>
              <div className="grid grid-cols-2 gap-3 pt-1">
                {(['No', 'Yes'] as YesNo[]).map(opt => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setFormData({ ...formData, alcoholDrinking: opt as AlcoholDrinking })}
                    className={`py-2 px-3 text-sm font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.alcoholDrinking === opt
                        ? 'bg-teal-50 border-teal-600 text-teal-900'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt === 'Yes' ? 'Yes (Heavy Drinker)' : 'No (None or Moderate)'}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: _DRNKWK1</span>
            </div>
          </div>
        )}

        {/* STEP 3: Medical Conditions */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-lg font-semibold text-slate-900">Clinical & Medical History</h3>
              <p className="text-xs text-slate-500">Diagnoses of hypertension, hypercholesterolemia, and glucose dysregulation.</p>
            </div>

            {/* High Blood Pressure */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Ever diagnosed with High Blood Pressure? <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {(['No', 'Yes'] as YesNo[]).map(opt => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setFormData({ ...formData, highBloodPressure: opt })}
                    className={`py-2.5 px-3 text-sm font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.highBloodPressure === opt
                        ? 'bg-teal-50 border-teal-600 text-teal-900'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt === 'Yes' ? 'Yes (Diagnosed Hypertension)' : 'No (Normal Blood Pressure)'}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: _RFHYPE5</span>
            </div>

            {/* High Cholesterol */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Ever told your Blood Cholesterol is High? <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {(['No', 'Yes'] as YesNo[]).map(opt => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setFormData({ ...formData, highCholesterol: opt })}
                    className={`py-2.5 px-3 text-sm font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.highCholesterol === opt
                        ? 'bg-teal-50 border-teal-600 text-teal-900'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt === 'Yes' ? 'Yes (Diagnosed Hypercholesterolemia)' : 'No (Normal Cholesterol)'}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: _RFCHOL2</span>
            </div>

            {/* Diabetes */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Ever diagnosed with Diabetes? <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {([
                  'No',
                  'Yes',
                  'Borderline / Pre-diabetes',
                  'Gestational only'
                ] as DiabetesStatus[]).map(opt => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setFormData({ ...formData, diabetes: opt })}
                    className={`py-2.5 px-3 text-xs sm:text-sm font-medium rounded-lg border text-left transition-colors cursor-pointer ${
                      formData.diabetes === opt
                        ? 'bg-teal-50 border-teal-600 text-teal-900 font-semibold'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: DIABETE4</span>
            </div>

            {/* Stroke History */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Ever told you had a Stroke? <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {(['No', 'Yes'] as YesNo[]).map(opt => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setFormData({ ...formData, stroke: opt })}
                    className={`py-2.5 px-3 text-sm font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.stroke === opt
                        ? 'bg-teal-50 border-teal-600 text-teal-900'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt === 'Yes' ? 'Yes (History of Stroke)' : 'No (No Stroke History)'}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: CVDSTRK3</span>
            </div>
          </div>
        )}

        {/* STEP 4: General Health & Consent */}
        {step === 4 && (
          <div className="space-y-6">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-lg font-semibold text-slate-900">Functional Status & Screening Consent</h3>
              <p className="text-xs text-slate-500">Overall health perception, mobility limitations, and statutory disclaimer.</p>
            </div>

            {/* General Health Rating */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Would you say that in general your health is: <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {(['Excellent', 'Very good', 'Good', 'Fair', 'Poor'] as GeneralHealth[]).map(gh => (
                  <button
                    key={gh}
                    type="button"
                    onClick={() => setFormData({ ...formData, generalHealth: gh })}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.generalHealth === gh
                        ? 'bg-teal-50 border-teal-600 text-teal-900 font-semibold'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {gh}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: GENHLTH</span>
            </div>

            {/* Difficulty Walking */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                Do you have serious difficulty walking or climbing stairs? <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {(['No', 'Yes'] as YesNo[]).map(opt => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setFormData({ ...formData, diffWalking: opt })}
                    className={`py-2.5 px-3 text-sm font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.diffWalking === opt
                        ? 'bg-teal-50 border-teal-600 text-teal-900'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt === 'Yes' ? 'Yes (Mobility Limitation)' : 'No (Unimpaired Walking)'}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">CDC variable: DIFFWALK</span>
            </div>

            {/* Mandatory Acknowledgement Box */}
            <div className="bg-amber-50/90 border border-amber-300/80 rounded-xl p-5 space-y-3">
              <div className="flex items-start gap-3">
                <input
                  id="disclaimer-check"
                  type="checkbox"
                  checked={formData.disclaimerAccepted}
                  onChange={e => setFormData({ ...formData, disclaimerAccepted: e.target.checked })}
                  className="mt-1 w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-600 cursor-pointer"
                />
                <label htmlFor="disclaimer-check" className="text-xs sm:text-sm text-amber-950 font-medium leading-relaxed cursor-pointer">
                  I understand this is an educational risk screening tool and NOT medical advice or a medical diagnosis.
                  <span className="block text-xs font-normal text-amber-800 mt-1">
                    Results reflect statistical associations in the CDC BRFSS public surveillance dataset. I understand that only a licensed medical doctor can diagnose coronary heart disease or myocardial infarction.
                  </span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Controls */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-200">
          <div className="flex items-center gap-2">
            {step > 1 && (
              <button
                type="button"
                onClick={handleBack}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleSaveDraft}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              title="Save current answers to browser local storage"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Draft</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            {step < 4 ? (
              <button
                type="button"
                onClick={handleNext}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                <span>Continue</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={!formData.disclaimerAccepted}
                className={`inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold rounded-lg shadow-sm transition-colors ${
                  formData.disclaimerAccepted
                    ? 'bg-teal-600 hover:bg-teal-700 text-white cursor-pointer'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>Generate Risk Analysis</span>
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};
