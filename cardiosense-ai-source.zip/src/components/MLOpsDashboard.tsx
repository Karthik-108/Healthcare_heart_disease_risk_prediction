/**
 * CardioSense AI - MLOps & Production Monitoring Dashboard
 */

import React, { useState } from 'react';
import { DriftMetric } from '../types/cardio';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  LineChart,
  Line
} from 'recharts';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Shield,
  Layers,
  ArrowUpRight,
  Clock,
  Database,
  Lock,
  GitBranch,
  Check
} from 'lucide-react';

const DRIFT_METRICS: DriftMetric[] = [
  {
    feature: 'ageCategory',
    baselineMean: 53.4,
    currentMean: 54.1,
    psi: 0.042,
    status: 'nominal'
  },
  {
    feature: 'bmi',
    baselineMean: 28.2,
    currentMean: 28.6,
    psi: 0.058,
    status: 'nominal'
  },
  {
    feature: 'highBloodPressure',
    baselineMean: 0.408,
    currentMean: 0.422,
    psi: 0.031,
    status: 'nominal'
  },
  {
    feature: 'smokingStatus',
    baselineMean: 0.142,
    currentMean: 0.151,
    psi: 0.038,
    status: 'nominal'
  },
  {
    feature: 'sleepHours',
    baselineMean: 7.04,
    currentMean: 6.82,
    psi: 0.114,
    status: 'moderate_drift'
  },
  {
    feature: 'generalHealth',
    baselineMean: 2.54,
    currentMean: 2.61,
    psi: 0.049,
    status: 'nominal'
  }
];

const PREDICTION_TIME_SERIES = [
  { day: 'Nov 01', low: 65, moderate: 25, high: 10, volume: 1840 },
  { day: 'Nov 02', low: 64, moderate: 26, high: 10, volume: 1920 },
  { day: 'Nov 03', low: 66, moderate: 24, high: 10, volume: 2100 },
  { day: 'Nov 04', low: 63, moderate: 26, high: 11, volume: 2310 },
  { day: 'Nov 05', low: 64, moderate: 25, high: 11, volume: 2150 },
  { day: 'Nov 06', low: 65, moderate: 25, high: 10, volume: 2160 }
];

export const MLOpsDashboard: React.FC = () => {
  const [retrainingStatus, setRetrainingStatus] = useState<'idle' | 'evaluating' | 'ready_for_review' | 'approved'>('idle');
  const [reviewNote, setReviewNote] = useState<string>('');

  const triggerShadowEvaluation = () => {
    setRetrainingStatus('evaluating');
    setTimeout(() => {
      setRetrainingStatus('ready_for_review');
    }, 1800);
  };

  const handleApproveRetrainedModel = () => {
    setRetrainingStatus('approved');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 py-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider">
            <span>Continuous Quality & Drift Surveillance</span>
            <span aria-hidden="true">·</span>
            <span>Admin Console</span>
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 mt-1">
            Production Telemetry & MLOps Governance
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Real-time API performance, Population Stability Index (PSI) data drift, alert rule gates, and human-in-the-loop retraining validation.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-600 bg-white border border-slate-200 px-3 py-2 rounded-lg">
          <GitBranch className="w-4 h-4 text-teal-600" />
          <span>Active Serving Model: <strong className="text-slate-900 font-mono">v1.4.2-calibrated-hgb</strong></span>
        </div>
      </div>

      {/* KPI Telemetry Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs uppercase font-medium text-slate-400">API Availability</span>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900">99.98 %</div>
          <span className="text-xs text-emerald-600 font-medium">Uptime target SLA: 99.9%</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs uppercase font-medium text-slate-400">Inference Latency (p95)</span>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900">114 ms</div>
          <span className="text-xs text-slate-500">p50: 38ms (threshold &lt; 1000ms)</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs uppercase font-medium text-slate-400">API Error Rate</span>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900">0.12 %</div>
          <span className="text-xs text-emerald-600 font-medium">Under critical alert limit (&lt; 2%)</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs uppercase font-medium text-slate-400">Total 7-Day Invocations</span>
          <div className="text-2xl font-bold font-mono tabular-nums text-teal-700">12,480</div>
          <span className="text-xs text-slate-500">Zero missing critical inputs</span>
        </div>
      </div>

      {/* 5 Real-Time Production Alert Rules Matrix */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">Production Alert Rules & Guardrails</h3>
            <p className="text-xs text-slate-500">Automated triggers guarding clinical inference stability and fairness.</p>
          </div>
          <span className="text-xs font-mono text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 font-semibold">
            All 5 Guardrails Passing
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
            <span className="font-semibold text-slate-800 block">1. Error Rate Rule</span>
            <span className="text-slate-500 block">Threshold: &gt; 2.0%</span>
            <div className="flex items-center gap-1 text-emerald-700 font-bold font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>0.12% (Nominal)</span>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
            <span className="font-semibold text-slate-800 block">2. Latency Rule</span>
            <span className="text-slate-500 block">Threshold: &gt; 1,000ms</span>
            <div className="flex items-center gap-1 text-emerald-700 font-bold font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>114ms (Fast)</span>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
            <span className="font-semibold text-slate-800 block">3. Data Drift PSI</span>
            <span className="text-slate-500 block">Threshold: PSI &gt; 0.20</span>
            <div className="flex items-center gap-1 text-emerald-700 font-bold font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Max: 0.114 (Stable)</span>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
            <span className="font-semibold text-slate-800 block">4. Risk Distribution Shift</span>
            <span className="text-slate-500 block">Threshold: &gt; 25% change</span>
            <div className="flex items-center gap-1 text-emerald-700 font-bold font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>High Risk: 10.2% (Steady)</span>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
            <span className="font-semibold text-slate-800 block">5. Subgroup Disparity</span>
            <span className="text-slate-500 block">Threshold: &gt; 10% Recall delta</span>
            <div className="flex items-center gap-1 text-emerald-700 font-bold font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Delta: 2.4% (Passing)</span>
            </div>
          </div>
        </div>
      </section>

      {/* Grid: Drift Monitoring + Prediction Distributions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* PSI Data Drift Table */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Population Stability Index (PSI) Feature Drift
              </h3>
              <p className="text-xs text-slate-500">
                Monitors shifts between serving traffic and the 40,000 CDC BRFSS training baseline.
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              PSI &lt; 0.10: Stable · 0.10 - 0.20: Moderate · &gt; 0.20: Significant Drift
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Feature Name</th>
                  <th className="py-2.5 px-3">Baseline Mean</th>
                  <th className="py-2.5 px-3">7-Day Serving Mean</th>
                  <th className="py-2.5 px-3">PSI Metric</th>
                  <th className="py-2.5 px-3">Surveillance Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono tabular-nums text-slate-800">
                {DRIFT_METRICS.map(item => (
                  <tr key={item.feature} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-900">{item.feature}</td>
                    <td className="py-2.5 px-3">{item.baselineMean}</td>
                    <td className="py-2.5 px-3">{item.currentMean}</td>
                    <td className="py-2.5 px-3 font-bold">{item.psi.toFixed(3)}</td>
                    <td className="py-2.5 px-3 font-sans">
                      {item.status === 'nominal' ? (
                        <span className="text-emerald-700 font-semibold text-[11px]">Stable (PSI &lt; 0.10)</span>
                      ) : (
                        <span className="text-amber-700 font-semibold text-[11px]">Moderate Shift (PSI: {item.psi})</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Prediction Distribution over time */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Risk Category Distribution (7 Days)
            </h3>
            <p className="text-xs text-slate-500">
              Tracking serving output distribution consistency.
            </p>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={PREDICTION_TIME_SERIES} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} unit="%" />
                <Tooltip />
                <Bar dataKey="low" stackId="a" fill="#0d9488" name="Low Risk" />
                <Bar dataKey="moderate" stackId="a" fill="#f59e0b" name="Moderate Risk" />
                <Bar dataKey="high" stackId="a" fill="#e11d48" name="High Risk" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Low: ~64.5%</span>
            <span>Moderate: ~25.3%</span>
            <span>High: ~10.2%</span>
          </div>
        </div>
      </div>

      {/* Human-in-the-Loop Model Retraining & Staging Gate */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-amber-600" />
              <h3 className="text-lg font-bold text-slate-900">
                Medical Retraining Governance & Deployment Gate
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              <strong>Mandatory Protocol:</strong> In healthcare risk applications, retrained models are NEVER automatically deployed into production. Every candidate model requires shadow validation, subgroup bias review, and explicit human sign-off.
            </p>
          </div>

          {retrainingStatus === 'idle' && (
            <button
              onClick={triggerShadowEvaluation}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm transition-colors cursor-pointer shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Trigger Shadow Evaluation</span>
            </button>
          )}
        </div>

        {retrainingStatus === 'evaluating' && (
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-center gap-3 text-sm text-slate-700">
            <RefreshCw className="w-5 h-5 text-teal-600 animate-spin" />
            <span>Evaluating Candidate Model v1.4.3 against CDC 2021 holdout validation split...</span>
          </div>
        )}

        {retrainingStatus === 'ready_for_review' && (
          <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-amber-950">
                Candidate Model Evaluation Ready: HistGB v1.4.3
              </span>
              <span className="text-xs font-mono text-amber-800 bg-amber-100 px-2 py-0.5 rounded font-semibold">
                Pending Human Approval
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
              <div className="bg-white p-3 rounded-lg border border-amber-200">
                <span className="font-sans text-slate-500 block">Candidate Recall</span>
                <strong className="text-teal-700 text-sm">47.2% (+0.4%)</strong>
              </div>
              <div className="bg-white p-3 rounded-lg border border-amber-200">
                <span className="font-sans text-slate-500 block">Candidate PR-AUC</span>
                <strong className="text-teal-700 text-sm">0.455 (+0.003)</strong>
              </div>
              <div className="bg-white p-3 rounded-lg border border-amber-200">
                <span className="font-sans text-slate-500 block">Brier Score</span>
                <strong className="text-slate-800 text-sm">0.058 (Improved)</strong>
              </div>
              <div className="bg-white p-3 rounded-lg border border-amber-200">
                <span className="font-sans text-slate-500 block">Subgroup Delta</span>
                <strong className="text-slate-800 text-sm">2.1% (Safe)</strong>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-medium text-amber-950">
                Clinical Safety & Audit Review Sign-off Notes:
              </label>
              <textarea
                rows={2}
                value={reviewNote}
                onChange={e => setReviewNote(e.target.value)}
                placeholder="Enter clinical reviewer name, validation audit ID, and justification for model promotion..."
                className="w-full bg-white border border-amber-300 rounded-lg p-2.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setRetrainingStatus('idle')}
                className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Reject / Cancel
              </button>
              <button
                onClick={handleApproveRetrainedModel}
                disabled={!reviewNote.trim()}
                className={`px-4 py-2 text-xs font-bold rounded-lg shadow-sm transition-colors ${
                  reviewNote.trim()
                    ? 'bg-teal-600 hover:bg-teal-700 text-white cursor-pointer'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                Approve & Promote to Serving (v1.4.3)
              </button>
            </div>
          </div>
        )}

        {retrainingStatus === 'approved' && (
          <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>
                <strong>Model Promotion Approved:</strong> Candidate v1.4.3 successfully validated and staged with cryptographic audit signature. Audit log appended.
              </span>
            </div>
            <button
              onClick={() => setRetrainingStatus('idle')}
              className="text-xs font-medium text-emerald-800 underline hover:text-emerald-950 cursor-pointer"
            >
              Reset Console
            </button>
          </div>
        )}
      </section>
    </div>
  );
};
