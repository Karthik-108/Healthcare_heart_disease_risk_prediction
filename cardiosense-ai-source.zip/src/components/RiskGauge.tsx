/**
 * CardioSense AI - Calibrated Risk Gauge Dial
 */

import React from 'react';
import { RiskCategory } from '../types/cardio';

interface RiskGaugeProps {
  probabilityPercent: number; // 0 to 100
  riskCategory: RiskCategory;
  confidenceInterval: [number, number];
}

export const RiskGauge: React.FC<RiskGaugeProps> = ({
  probabilityPercent,
  riskCategory,
  confidenceInterval
}) => {
  // Map probability 0% - 60% to angle -90 to +90 deg (clamping max display at 60% since clinical risk rarely exceeds 60%)
  const clampedProb = Math.min(Math.max(probabilityPercent, 0), 60);
  const rotationDegrees = -90 + (clampedProb / 60) * 180;

  // Color schemes
  const getColors = () => {
    switch (riskCategory) {
      case 'High':
        return {
          text: 'text-rose-700',
          bg: 'bg-rose-50',
          border: 'border-rose-200',
          label: 'High Risk'
        };
      case 'Moderate':
        return {
          text: 'text-amber-700',
          bg: 'bg-amber-50',
          border: 'border-amber-200',
          label: 'Moderate Risk'
        };
      case 'Low':
      default:
        return {
          text: 'text-teal-700',
          bg: 'bg-teal-50',
          border: 'border-teal-200',
          label: 'Low Risk'
        };
    }
  };

  const style = getColors();

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-white rounded-xl border border-slate-200 shadow-xs">
      <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
        Calibrated Population Risk Index
      </div>

      {/* SVG Semi-Circle Dial */}
      <div className="relative w-64 h-36 flex items-center justify-center overflow-hidden">
        <svg viewBox="0 0 200 110" className="w-full h-full">
          {/* Background Arc Track */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="16"
            strokeLinecap="round"
          />

          {/* Low Risk Zone (0% - 10% -> 0 - 30 deg on 0-180 scale) */}
          <path
            d="M 20 100 A 80 80 0 0 1 54 44"
            fill="none"
            stroke="#0d9488"
            strokeWidth="16"
            strokeOpacity="0.85"
          />

          {/* Moderate Risk Zone (10% - 25% -> 30 - 75 deg on 0-180 scale) */}
          <path
            d="M 54 44 A 80 80 0 0 1 125 24"
            fill="none"
            stroke="#f59e0b"
            strokeWidth="16"
            strokeOpacity="0.85"
          />

          {/* High Risk Zone (25%+ -> 75 - 180 deg on 0-180 scale) */}
          <path
            d="M 125 24 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="#e11d48"
            strokeWidth="16"
            strokeOpacity="0.85"
          />

          {/* Dial Center Pivot */}
          <circle cx="100" cy="100" r="7" fill="#0f172a" />

          {/* Dynamic Needle */}
          <g transform={`rotate(${rotationDegrees} 100 100)`} className="transition-transform duration-700 ease-out">
            <line
              x1="100"
              y1="100"
              x2="100"
              y2="28"
              stroke="#0f172a"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
            <circle cx="100" cy="30" r="3" fill="#0f172a" />
          </g>
        </svg>

        {/* Labels on dial endpoints */}
        <div className="absolute bottom-0 left-4 text-[10px] font-mono text-slate-400">0%</div>
        <div className="absolute top-1 left-16 text-[10px] font-mono text-teal-700">10%</div>
        <div className="absolute top-0 right-20 text-[10px] font-mono text-amber-700">25%</div>
        <div className="absolute bottom-0 right-4 text-[10px] font-mono text-rose-700">60%+</div>
      </div>

      {/* Probability Readout */}
      <div className="text-center mt-2 space-y-1">
        <div className="flex items-baseline justify-center gap-1.5">
          <span className={`text-4xl font-extrabold font-mono tabular-nums tracking-tight ${style.text}`}>
            {probabilityPercent}%
          </span>
          <span className="text-xs uppercase font-semibold text-slate-500">
            Estimated Likelihood
          </span>
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Category:{' '}
          <span className={`font-semibold ${style.text}`}>
            {style.label}
          </span>
          <span className="text-slate-300 mx-1.5">·</span>
          <span>95% CI: [{confidenceInterval[0]}% - {confidenceInterval[1]}%]</span>
        </div>
      </div>

      {/* Legend & Calibration Footnote */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between w-full text-[11px] text-slate-500">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-teal-600 inline-block" />
          <span>Low (&lt;10%)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
          <span>Moderate (10-25%)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-rose-600 inline-block" />
          <span>High (&ge;25%)</span>
        </div>
      </div>
    </div>
  );
};
