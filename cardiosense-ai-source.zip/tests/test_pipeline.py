"""
CardioSense AI - Comprehensive Unit & Pipeline Test Suite
Tests:
1. Pydantic form input validation & range enforcement
2. Target leakage prevention guarantees
3. Deterministic reproducibility (same input -> same output for same model version)
4. Calibrated probability bounds [0.01, 0.99]
5. SHAP attribution conservation
6. Population Stability Index (PSI) drift monitor logic
"""

import math
import pytest
from pydantic import ValidationError

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend')))

from schemas import AssessmentInputSchema
from model_service import compute_prediction_and_shap, MODEL_VERSION


# 1. VALID INPUT FIXTURE
@pytest.fixture
def valid_assessment_payload():
    return {
        "age_category": "Age 55-59",
        "sex": "Male",
        "bmi": 28.4,
        "smoking_status": "Former smoker",
        "alcohol_drinking": "No",
        "physical_activity": "Yes",
        "sleep_hours": 7,
        "high_blood_pressure": "Yes",
        "high_cholesterol": "Yes",
        "diabetes": "Borderline / Pre-diabetes",
        "stroke": "No",
        "general_health": "Good",
        "diff_walking": "No",
        "disclaimer_accepted": True
    }


# 2. VALIDATION TESTS
def test_valid_payload_parsing(valid_assessment_payload):
    schema = AssessmentInputSchema(**valid_assessment_payload)
    assert schema.age_category == "Age 55-59"
    assert schema.bmi == 28.4
    assert schema.disclaimer_accepted is True


def test_disclaimer_acceptance_enforcement(valid_assessment_payload):
    invalid_payload = valid_assessment_payload.copy()
    invalid_payload["disclaimer_accepted"] = False
    with pytest.raises(ValidationError) as exc:
        AssessmentInputSchema(**invalid_payload)
    assert "You must acknowledge that this is an educational screening" in str(exc.value)


def test_bmi_biological_bounds(valid_assessment_payload):
    # Test impossible low BMI (<12)
    invalid_payload = valid_assessment_payload.copy()
    invalid_payload["bmi"] = 8.5
    with pytest.raises(ValidationError):
        AssessmentInputSchema(**invalid_payload)

    # Test impossible high BMI (>75)
    invalid_payload["bmi"] = 92.0
    with pytest.raises(ValidationError):
        AssessmentInputSchema(**invalid_payload)


def test_sleep_hours_bounds(valid_assessment_payload):
    invalid_payload = valid_assessment_payload.copy()
    invalid_payload["sleep_hours"] = 28
    with pytest.raises(ValidationError):
        AssessmentInputSchema(**invalid_payload)


def test_extra_fields_forbidden(valid_assessment_payload):
    invalid_payload = valid_assessment_payload.copy()
    invalid_payload["_MICHD"] = 1  # Attempted target injection
    with pytest.raises(ValidationError):
        AssessmentInputSchema(**invalid_payload)


# 3. LEAKAGE PREVENTION TEST
def test_target_leakage_prohibition():
    """
    Verifies that the target label _MICHD or direct outcome proxies
    are NOT accepted in input schema fields.
    """
    fields = AssessmentInputSchema.model_fields.keys()
    assert "_MICHD" not in fields
    assert "target" not in fields
    assert "heart_attack" not in fields
    assert "myocardial_infarction" not in fields


# 4. DETERMINISTIC REPRODUCIBILITY TEST
def test_deterministic_prediction_reproducibility(valid_assessment_payload):
    """
    Verifies that identical inputs evaluated with the same model version
    produce exactly identical probability and SHAP attribution values.
    """
    schema = AssessmentInputSchema(**valid_assessment_payload)
    result_1 = compute_prediction_and_shap(schema)
    result_2 = compute_prediction_and_shap(schema)

    assert result_1.model_version == result_2.model_version == MODEL_VERSION
    assert result_1.probability_percent == result_2.probability_percent
    assert result_1.risk_category == result_2.risk_category
    assert result_1.confidence_interval == result_2.confidence_interval

    # Compare SHAP values
    assert len(result_1.shap_factors) == len(result_2.shap_factors)
    for f1, f2 in zip(result_1.shap_factors, result_2.shap_factors):
        assert f1.feature == f2.feature
        assert f1.shap_value == f2.shap_value


# 5. CALIBRATED PROBABILITY BOUNDS TEST
def test_calibrated_probability_bounds(valid_assessment_payload):
    """
    Verifies that probability is strictly bounded within realistic clinical limits
    and confidence intervals do not collapse or invert.
    """
    schema = AssessmentInputSchema(**valid_assessment_payload)
    result = compute_prediction_and_shap(schema)

    assert 0.1 <= result.probability_percent <= 99.0
    ci_lower, ci_upper = result.confidence_interval
    assert ci_lower < ci_upper
    assert ci_lower >= 0.1
    assert ci_upper <= 99.0


# 6. SHAP CONSERVATION TEST
def test_shap_factors_attribution(valid_assessment_payload):
    """
    Verifies that high-risk inputs (hypertension, smoking, diabetes)
    produce positive risk-increasing SHAP contributions.
    """
    schema = AssessmentInputSchema(**valid_assessment_payload)
    result = compute_prediction_and_shap(schema)

    hbp_factor = next(f for f in result.shap_factors if f.feature == "high_blood_pressure")
    assert hbp_factor.shap_value > 0
    assert hbp_factor.direction == "increases_risk"


# 7. POPULATION STABILITY INDEX (PSI) DRIFT CALCULATION TEST
def test_psi_calculation_logic():
    """
    Verifies Population Stability Index formula:
    PSI = sum((actual% - expected%) * ln(actual% / expected%))
    """
    expected = [0.20, 0.30, 0.30, 0.20]
    # Small drift: close to expected
    actual_stable = [0.21, 0.29, 0.31, 0.19]

    psi_stable = sum((a - e) * math.log(a / e) for a, e in zip(actual_stable, expected))
    assert psi_stable < 0.10  # Stable threshold

    # Heavy drift
    actual_drifted = [0.05, 0.45, 0.40, 0.10]
    psi_drifted = sum((a - e) * math.log(a / e) for a, e in zip(actual_drifted, expected))
    assert psi_drifted > 0.20  # Critical drift threshold
